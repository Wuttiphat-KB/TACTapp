import os
import time
import pytz
import asyncio
import logging
import calendar
import websockets
from datetime import timezone
from datetime import datetime
from ocpp.routing import on
from ocpp.v16 import ChargePoint as cp
from ocpp.v16 import call, call_result
from ocpp.v16.enums import RemoteStartStopStatus, Action, AuthorizationStatus, RegistrationStatus
from helpf.plc_function import *
from helpf.len_meter_test import *
import paho.mqtt.client as mqtt
import json
from sdnotify import SystemdNotifier

notifier = SystemdNotifier()
broker = "212.80.215.42"
port = 1883
client = mqtt.Client()
def on_connect(client, userdata, flags, rc):
    print(f"Connected with result code {rc}")
client.on_connect = on_connect
client.connect(broker, port, 60)
client.loop_start()
OCPPSTATION = "TACT30KW"
#broker = "212.80.215.42"
#port = 1883
#client = mqtt.Client()
#def on_connect(client, userdata, flags, rc):
#    print(f"Connected with result code {rc}")
#client.on_connect = on_connect
#client.connect(broker, port, 60)
#client.loop_start()
#OCPPSTATION = "teststation"

#def line_notify(message):
#    url = 'https://notify-api.line.me/api/notify'
#    token = 'a9wbwa2QEstfuCBd2cpRGf2hNcA4XywWXkg9VPCkV6H'
#    headers = {
#       'Content-Type': 'application/x-www-form-urlencoded',
#        'Authorization': 'Bearer ' + token
#    }
#   data = {'message': message}
#    r = requests.post(url, headers=headers, data=data)

def line_notify(message):
    try:
      bot_token = '7634047926:AAHGNSgAFZg_FeTh9UKLFKNxC0pnR5a6wpY'
      chat_id = '-4658762233'
      url = f'https://api.telegram.org/bot{bot_token}/sendMessage'
      data = {'chat_id': chat_id, 'text': message}
      response = requests.post(url, data=data).json()
    except Exception as e:
      response = "telegramerror"
    return response

async def systemd_watchdog_task():
    while True:
        notifier.notify("WATCHDOG=1")
        await asyncio.sleep(10)
        
def convert_timeformat(current_time):
    formatted_time = current_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + 'Z'
    return formatted_time


log_name = datetime.now(pytz.timezone('Asia/Bangkok')).strftime("%Y%m%d_%H%M%S")
print(f"## log_name: {log_name}")

logging.basicConfig(level=logging.INFO)
file_handler = logging.FileHandler(log_name + '.log')
file_handler.setLevel(logging.DEBUG)
# Create a logging format
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
# Get the root logger and add the file handler to it
logger = logging.getLogger()
logger.addHandler(file_handler)

ip_adr1, ip_adr2 = '192.168.0.8', '192.168.0.8'
ip_Meter1, ip_Meter2 = '/dev/ttyUSB0', '/dev/ttyACM0'
icp_ini1, usi_ini1 = read_tag_status(ip_adr1)
icp_ini2, usi_ini2 = read_tag_status(ip_adr2)


class AuthorizationCache:
    def __init__(self, size):
        self.cache = {}
        self.size = size

    def add(self, identifier, idTagInfo):
        if len(self.cache) >= self.size:
            self.remove_not_valid()
            if len(self.cache) >= self.size:
                self.remove_oldest_valid()
        self.cache[identifier] = {
            'idTagInfo': idTagInfo,
            'timestamp': convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)),
        }

    def update(self, identifier, idTagInfo):
        self.cache[identifier]['idTagInfo'] = idTagInfo
        self.cache[identifier]['timestamp'] = convert_timeformat(
            datetime.now(timezone.utc).replace(tzinfo=timezone.utc))

    def expire(self, identifier):
        if identifier in self.cache:
            self.cache[identifier]['idTagInfo']['status'] = "Expired"

    def remove_not_valid(self):
        self.cache = {k: v for k, v, in self.cache.items() if v['idTagInfo']['status'] != "NotValid"}

    def remove_oldest_valid(self):
        valid_entries = [(k, v) for k, v, in self.cache.items() if v['idTagInfo']['status'] == "Accepted"]
        valid_entries.sort(key=lambda x: x[1]['timestamp'])
        if valid_entries:
            del self.cache[valid_entries[0][0]]


class LocalAuthorizationList:
    def __init__(self, max_length):
        self.max_length = max_length
        self.identifiers = {}  # Stores authorization details

    def add(self, identifier, status, expiration_date=None):
        if len(self.identifiers) < self.max_length:
            self.identifiers[identifier] = {
                'status': status,
                'expiration_date': expiration_date
            }

    def update(self, identifier, status, expiration_date=None):
        if identifier in self.identifiers:
            self.identifiers[identifier]['status'] = status
            self.identifiers[identifier]['expiration_date'] = expiration_date

    def delete(self, identifier):
        if identifier in self.identifiers:
            del self.identifiers[identifier]

    def replace_list(self, new_list):
        if len(new_list) <= self.max_length:
            self.identifiers = new_list


############################ Main Program  ############################
class ChargePoint(cp):
    def __init__(self, identifier, websocket,
                 iCpStateCss1=icp_ini1,
                 iCpStateCss2=icp_ini2,
                 usiLinkStateCcs1=usi_ini1,
                 usiLinkStateCcs2=usi_ini2
                 ):
        super().__init__(identifier, websocket)

        ## Connector-1
        self.iCpStateCss1 = iCpStateCss1
        self.myconnector_id_c1 = 1
        self.myip_adr_c1 = '192.168.0.8'
        self.myremotestart_c1 = 0
        self.myid_tag_c1 = "Default"
        self.my_meter_ip_c1 = '/dev/ttyACM0'
        self.stage1_sent_done_c1 = 0
        self.transactionId_c1 = None
        self.my_remote_stop_c1 = 0
        self.emergency_sent_c1 = 0
        self.emergency_sent_Sw_c1 = 1
        self.usiLinkStateCcs1 = usiLinkStateCcs1
        self.myid_tag_ath_c1 = "Default"
        self.finshing_sent_c1 = 0
        self.finshing_sent_sw_c1 = 1
        self.start_trans_SW_c1 = 1
        self.block1 = 0
        self.accepted_tag1 = '0'
        self.accepted_tag2 = '0'
        self.start_transaction_SW1 = 1
        self.start_sendMeterValue_SW1 = 1
        self.meter_start1 = int(get_meter_value_pilot(self.my_meter_ip_c1)['energyTotal'] * 1000)  # Wh
        self.meter_stop1 = int(get_meter_value_pilot(self.my_meter_ip_c1)['energyTotal'] * 1000)
        self.timestamp1 = datetime.now(pytz.timezone('Asia/Bangkok')).strftime("%Y-%m-%dT%H:%M:%S.%f")

        ## Connector-1
        va1 = open("block1.txt", "r")
        va2 = open("emergency_sent_c1.txt", "r")
        va3 = open("emergency_sent_Sw_c1.txt", "r")
        va4 = open("finshing_sent_c1.txt", "r")
        va5 = open("finshing_sent_sw_c1.txt", "r")
        va6 = open("my_remote_stop_c1.txt", "r")
        va7 = open("myid_tag_ath_c1.txt", "r")
        va8 = open("myid_tag_c1.txt", "r")
        va9 = open("myremotestart_c1.txt", "r")
        va10 = open("start_trans_SW_c1.txt", "r")
        va11 = open("start_transaction_SW1.txt", "r")
        va12 = open("start_sendMeterValue_SW1.txt", "r")
        va13 = open("iCpStateCss1.txt", "r")
        va14 = open("translogs1.txt", "r")
        va15 = open("usiLinkState1_regis.txt", "r")

        self.block1 = int(va1.read())
        self.emergency_sent_c1 = int(va2.read())
        self.emergency_sent_Sw_c1 = int(va3.read())
        self.finshing_sent_c1 = int(va4.read())
        self.finshing_sent_sw_c1 = int(va5.read())
        self.my_remote_stop_c1 = int(va6.read())
        self.myid_tag_ath_c1 = va7.read()
        self.myid_tag_c1 = va8.read()
        self.myremotestart_c1 = int(va9.read())
        self.start_trans_SW_c1 = int(va10.read())
        self.start_transaction_SW1 = int(va11.read())
        self.start_sendMeterValue_SW1 = int(va12.read())
        self.iCp1_regis = str(va13.read())
        self.transactionId_c1 = int(va14.read())
        self.usiLinkState1_regis = str(va15.read())

        ## Connector-2
        self.iCpStateCss2 = iCpStateCss2
        self.myconnector_id_c2 = 2
        self.myip_adr_c2 = '192.168.0.8'
        self.myremotestart_c2 = 0
        self.myid_tag_c2 = None
        self.my_meter_ip_c2 = '/dev/ttyACM0'
        self.stage1_sent_done_c2 = 0
        self.transactionId_c2 = None
        self.my_remote_stop_c2 = 0
        self.emergency_sent_c2 = 0
        self.emergency_sent_Sw_c2 = 1
        self.usiLinkStateCcs2 = usiLinkStateCcs2
        self.myid_tag_ath_c2 = None
        self.finshing_sent_c2 = 0
        self.finshing_sent_sw_c2 = 1
        self.start_trans_SW_c2 = 1
        self.block2 = 0
        self.start_transaction_SW2 = 1
        self.start_sendMeterValue_SW2 = 1
        self.meter_start2 = int(get_meter_value_pilot(self.my_meter_ip_c2)['energyTotal'] * 1000)  # Wh
        self.meter_stop2 = int(get_meter_value_pilot(self.my_meter_ip_c2)['energyTotal'] * 1000)
        self.timestamp2 = datetime.now(pytz.timezone('Asia/Bangkok')).strftime("%Y-%m-%dT%H:%M:%S.%f")

        ## Connector-2
        vb1 = open("block2.txt", "r")
        vb2 = open("emergency_sent_c2.txt", "r")
        vb3 = open("emergency_sent_Sw_c2.txt", "r")
        vb4 = open("finshing_sent_c2.txt", "r")
        vb5 = open("finshing_sent_sw_c2.txt", "r")
        vb6 = open("my_remote_stop_c2.txt", "r")
        vb7 = open("myid_tag_ath_c2.txt", "r")
        vb8 = open("myid_tag_c2.txt", "r")
        vb9 = open("myremotestart_c2.txt", "r")
        vb10 = open("start_trans_SW_c2.txt", "r")
        vb11 = open("start_transaction_SW2.txt", "r")
        vb12 = open("start_sendMeterValue_SW2.txt", "r")
        va13 = open("iCpStateCss2.txt", "r")
        va14 = open("translogs2.txt", "r")
        va15 = open("usiLinkState2_regis.txt", "r")

        self.block2 = int(vb1.read())
        self.emergency_sent_c2 = int(vb2.read())
        self.emergency_sent_Sw_c2 = int(vb3.read())
        self.finshing_sent_c2 = int(vb4.read())
        self.finshing_sent_sw_c2 = int(vb5.read())
        self.my_remote_stop_c2 = int(vb6.read())
        self.myid_tag_ath_c2 = vb7.read()
        self.myid_tag_c2 = vb8.read()
        self.myremotestart_c2 = int(vb9.read())
        self.start_trans_SW_c2 = int(vb10.read())
        self.start_transaction_SW2 = int(vb11.read())
        self.start_sendMeterValue_SW2 = int(vb12.read())
        self.iCp2_regis = str(va13.read())
        self.transactionId_c2 = int(va14.read())
        self.usiLinkState2_regis = str(va15.read())

        f1 = open("HeartbeatInterval_cfg.txt", "r")
        f2 = open("AuthorizationCacheEnabled_cfg.txt", "r")
        f3 = open("LocalAuthListEnabled_cfg.txt", "r")
        f4 = open("MeterValuesSampledData_cfg.txt", "r")
        f6 = open("LocalAuthListMaxLength_cfg.txt", "r")
        f8 = open("StopTxnSampledData_cfg.txt", "r")
        f9 = open("AllowOfflineTxForUnknownId_cfg.txt", "r")
        f10 = open("AuthorizeRemoteTxRequests_cfg.txt", "r")
        f11 = open("LocalAuthorizeOffline_cfg.txt", "r")
        f12 = open("LocalPreAuthorize_cfg.txt", "r")
        f13 = open("MeterValueSampleInterval_cfg.txt", "r")
        f14 = open("StopTransactionOnInvalidId_cfg.txt", "r")

        self.HeartbeatInterval_cfg = f1.read()
        self.AuthorizationCacheEnabled_cfg = f2.read()
        self.LocalAuthListEnabled_cfg = f3.read()
        self.MeterValuesSampledData_cfg = str(f4.read())
        self.LocalAuthListMaxLength_cfg = int(f6.read())
        self.StopTxnSampledData_cfg = [f8.read()]
        self.AllowOfflineTxForUnknownId_cfg = f9.read()
        self.AuthorizeRemoteTxRequests_cfg = f10.read()
        self.LocalAuthorizeOffline_cfg = f11.read()
        self.LocalPreAuthorize_cfg = f12.read()
        self.MeterValueSampleInterval_cfg = f13.read()
        self.StopTransactionOnInvalidId_cfg = f14.read()

        # configuaration
        self.already_remote_start = None
        self.authorization_cache = AuthorizationCache(size=50)
        self.local_auth_list = LocalAuthorizationList(1000)
        
        self.block_sw1 = 1
        self.block_sw2 = 1
        self.block_sw3 = 1    

        self.block_sw1_C1 = 1
        self.block_sw2_C1 = 1
        self.block_sw3_C1 = 1 
        
        ## Addition
        vc1 = open("block_sw1.txt", "r")
        vc2 = open("block_sw2.txt", "r")
        vc3 = open("block_sw3.txt", "r")
        vc4 = open("block_sw1_C1.txt", "r")
        vc5 = open("block_sw2_C1.txt", "r")
        vc6 = open("block_sw3_C1.txt", "r")
        
        self.block_sw1 = int(vc1.read())
        self.block_sw2 = int(vc2.read())
        self.block_sw3 = int(vc3.read())
        self.block_sw1_C1 = int(vc4.read())
        self.block_sw2_C1 = int(vc5.read())
        self.block_sw3_C1 = int(vc6.read())

    async def authorize(self, id_tag):
        if self.AuthorizationCacheEnabled_cfg == 'true':  #
            cached_info = self.authorization_cache.cache.get(id_tag)
            print('cached_info', cached_info)
            if cached_info:
                if cached_info['idTagInfo']['status'] == "Accepted":
                    print('cached_info Accepted', cached_info['idTagInfo']['status'])
                    return call.AuthorizePayload(id_tag_info=cached_info['idTagInfo'])
                elif cached_info['idTagInfo']['status'] == "NotValid":
                    print('cached_info NotValid', cached_info['idTagInfo']['status'])
                    request = call.AuthorizePayload(id_tag=id_tag)
                    response = await self.call(request)
                    self.authorization_cache.update(id_tag, response.id_tag_info)
                    return response
        request = call.AuthorizePayload(id_tag=id_tag)
        print(f"authorize request: {request}")
        try:
            response = await self.call(request)
        except Exception as e:
            print(f"## error line 196: {e}")

        if self.AuthorizationCacheEnabled_cfg:
            self.authorization_cache.add(id_tag, response.id_tag_info)
        return response


    ############ Update 14-02-2568 22:35 Start ############
    @on(Action.SetChargingProfile)
    async def on_set_charging_profile(self, **kwargs):
        ### connector_id
        try:
            connector_id = kwargs['connector_id']
            print('connector_id type', type(connector_id), connector_id)
        except Exception as e:
            print("not found connector_id", " error: ", e)

        ### csChargingProfiles
        try:
            csChargingProfiles = kwargs['cs_charging_profiles']
            print("csChargingProfiles", csChargingProfiles)
        except Exception as e:
            print("not found csChargingProfiles", " error: ", e)

        ### chargingProfileId
        try:
            charging_profile_id = csChargingProfiles['charging_profile_id']
            print("charging_profile_id", charging_profile_id)
        except Exception as e:
            print("not found charging_profile_id", " error: ", e)

        ### stackLevel
        try:
            stack_level = csChargingProfiles['stack_level']
            print("stack_level", stack_level)
        except Exception as e:
            print("not found stack_level", " error: ", e)

        ### charging_profile_purpose
        try:
            charging_profile_purpose = csChargingProfiles['charging_profile_purpose']
            print("charging_profile_purpose", charging_profile_purpose)
        except Exception as e:
            print("not found charging_profile_purpose", " error: ", e)

        ### chargerProfileKind
        try:
            charging_profile_kind = csChargingProfiles['charging_profile_kind']
            print("charging_profile_kind", charging_profile_kind)
        except Exception as e:
            print("not found charging_profile_kind", " error: ", e)

        ### charging_schedule
        try:
            charging_schedule = csChargingProfiles['charging_schedule']
        except Exception as e:
            print("not found charging_schedule", " error: ", e)

        ### start_schedule
        try:
            start_schedule = charging_schedule['start_schedule']
            print("start_schedule", start_schedule)
        except Exception as e:
            print("not found start_schedule", " error: ", e)

        ### chargingRateUnit
        try:
            charging_rate_unit = charging_schedule['charging_rate_unit']
            print("charging_rate_unit", charging_rate_unit)
            fw1 = open("charging_rate_unit.txt", "w")
            fw1.write(str(charging_rate_unit))
            fw1.close()
        except Exception as e:
            print("not found charging_rate_unit", " error: ", e)

        ### chargingSchedulePeriod
        try:
            charging_schedule_period = charging_schedule['charging_schedule_period']
            print("charging_schedule_period", charging_schedule_period)
        except Exception as e:
            print("not found charging_schedule_period", " error: ", e)

        ### start_period
        try:
            start_period = charging_schedule_period[0]['start_period']
        except Exception as e:
            print("not found start_period", " error: ", e)

        ### limit
        try:
            limit = charging_schedule_period[0]['limit']
            fw1 = open("limit.txt", "w")
            fw1.write(str(limit))
            fw1.close()
        except Exception as e:
            print("not found limit", " error: ", e)

        ###########################################################

        try:
            print(f"connector_id: {connector_id}")
        except Exception as e:
            print("not found limit", " error: ", e)

        try:
            print(f"csChargingProfiles: {csChargingProfiles}")
        except Exception as e:
            print("not found csChargingProfiles", " error: ", e)

        try:
            print(f"charging_profile_id: {charging_profile_id}")
        except Exception as e:
            print("not found charging_profile_id", " error: ", e)

        try:
            print(f"stack_level: {stack_level}")
        except Exception as e:
            print("not found stack_level", " error: ", e)

        try:
            print(f"charging_profile_purpose: {charging_profile_purpose}")
        except Exception as e:
            print("not found charging_profile_purpose", " error: ", e)

        try:
            print(f"charging_profile_kind: {charging_profile_kind}")
        except Exception as e:
            print("not found charging_profile_kind", " error: ", e)

        try:
            print(f"charging_schedule: {charging_schedule}")
        except Exception as e:
            print("not found charging_schedule", " error: ", e)

        try:
            print(f"start_schedule: {start_schedule}")
        except Exception as e:
            print("not found start_schedule", " error: ", e)

        try:
            print(f"charging_rate_unit: {charging_rate_unit}")
        except Exception as e:
            print("not found charging_rate_unit", " error: ", e)

        try:
            print(f"charging_schedule_period: {charging_schedule_period}")
        except Exception as e:
            print("not found charging_schedule_period", " error: ", e)

        try:
            print(f"start_period: {start_period}")
        except Exception as e:
            print("not found start_period", " error: ", e)

        if connector_id == 0:
            if charging_rate_unit == "W":
                res3 = limit2connector(self.myip_adr_c1, 1)
                res4 = limit2connector(self.myip_adr_c2, 1)
                res1 = limitpower(self.myip_adr_c1, limit)
                res2 = limitpower(self.myip_adr_c2, limit)
                print('connector1 power limit', res1)
                print('connector2 power limit', res2)
                print('connector1 power sharing', res3)
                print('connector2 power sharing', res4)

                fw1 = open("status_limit0.txt", "w")
                fw1.write(str(1))
                fw1.close()

            elif charging_rate_unit == "A":
                res1 = limitcurrent(self.myip_adr_c1, limit)
                res2 = limitcurrent(self.myip_adr_c2, limit)
                print('connector1 current limit', res1)
                print('connector2 current limit', res2)
                
        elif connector_id == 1:
            if charging_rate_unit == "W":
                res1 = limitpower(self.myip_adr_c1, limit)
                print('connector1 power limit', res1)

                fw1 = open("status_limit1.txt", "w")
                fw1.write(str(1))
                fw1.close()

            elif charging_rate_unit == "A":
                res1 = limitcurrent(self.myip_adr_c1, limit)
                print('connector1 current limit', res1)
                
        elif connector_id == 2:
            if charging_rate_unit == "W":
                res2 = limitpower(self.myip_adr_c2, limit)
                print('connector2 power limit', res2)

                fw1 = open("status_limit2.txt", "w")
                fw1.write(str(1))
                fw1.close()

            elif charging_rate_unit == "A":
                res2 = limitcurrent(self.myip_adr_c2, limit)
                print('connector2 current limit', res2)

        return call_result.SetChargingProfilePayload(status="Accepted")

    
    ################### ClearChargingProfile ###################
    @on(Action.ClearChargingProfile)
    async def on_clear_chargingprofile(self, **kwargs):
        try:
            print("kwargs", kwargs)
        except Exception as e:
            print("not found kwargs", " error: ", e)

        try:
            connector_id = kwargs['connector_id']
        except Exception as e:
            print("not found connector_id", " error: ", e)

        if connector_id == 0:
            res1 = limitpower(self.myip_adr_c1, 150000)
            res2 = limitcurrent(self.myip_adr_c1, 400)
            print('connector1 power: ', res1)
            print('connector1 current: ', res2)

            res1 = limitpower(self.myip_adr_c2, 150000)
            res2 = limitcurrent(self.myip_adr_c2, 400)
            print('connector2 power: ', res1)
            print('connector2: current', res2)

            res3 = limit2connector(self.myip_adr_c1, False)
            res4 = limit2connector(self.myip_adr_c2, False)

            fw1 = open("limit.txt", "w")
            fw1.write(str(150000))
            fw1.close()

            fw1 = open("status_limit0.txt", "w")
            fw1.write(str(0))
            fw1.close()

        elif connector_id == 1:
            res1 = limitpower(self.myip_adr_c1, 150000)
            res2 = limitcurrent(self.myip_adr_c1, 400)
            print('connector1 power: ', res1)
            print('connector1 current: ', res2)

            fw1 = open("limit.txt", "w")
            fw1.write(str(150000))
            fw1.close()

            fw1 = open("status_limit1.txt", "w")
            fw1.write(str(0))
            fw1.close()

        elif connector_id == 2:
            res1 = limitpower(self.myip_adr_c2, 150000)
            res2 = limitcurrent(self.myip_adr_c2, 400)
            print('connector1 power: ', res1)
            print('connector1 current: ', res2)

            fw1 = open("limit.txt", "w")
            fw1.write(str(150000))
            fw1.close()

            fw1 = open("status_limit2.txt", "w")
            fw1.write(str(0))
            fw1.close()

        return call_result.ClearChargingProfilePayload(status="Accepted")

    ################### GetCompositeSchedule ###################
    @on(Action.GetCompositeSchedule) #Dict
    async def on_get_compositeSchedul(self, **kwargs):

        try:
            print("kwargs", kwargs)
        except Exception as e:
            print("not found kwargs", " error: ", e)

        try:
            connector_id = kwargs['connector_id']
        except Exception as e:
            print("not found kwargs", " error: ", e)

        f = open("charging_rate_unit.txt", "r")
        charging_rate_unit = str(f.read())

        f = open("limit.txt", "r")
        limit = int(f.read())


        if connector_id == 0:

            f = open("status_limit0.txt", "r")
            status_limit0 = int(f.read())
            
            if status_limit0 == 0:
                limit = 150000
            else:
                limit = limit

            return call_result.GetCompositeSchedulePayload(
                status = "Accepted",
                # status = GetCompositeScheduleStatus.accepted,
                connector_id = 0, #int
                schedule_start = convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)), #str
                charging_schedule = {
                    "duration": 0,
                    "chargingSchedulePeriod": [
                        {
                            "startPeriod": 0,
                            "numberPhases": 3,
                            "limit": limit
                        }
                    ],
                    "chargingRateUnit":charging_rate_unit
                }
            )

        elif connector_id == 1:

            f = open("status_limit0.txt", "r")
            status_limit0 = int(f.read())
            f = open("status_limit1.txt", "r")
            status_limit1 = int(f.read())

            if status_limit1 == 0 and status_limit0 == 0:
                limit = 150000
            elif (self.usiLinkStateCcs1 == 'Charging') and (self.iCpStateCss1 == 'Charging'):
                limit = float(limit/2)
            else:
                limit = limit

            return call_result.GetCompositeSchedulePayload(
                status = "Accepted",
                # status = GetCompositeScheduleStatus.accepted,
                connector_id = 1, #int
                schedule_start = convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)), #str
                charging_schedule = {
                    "duration": 0,
                    "chargingSchedulePeriod": [
                        {
                            "startPeriod": 0,
                            "numberPhases": 3,
                            "limit": limit
                        }
                    ],
                    "chargingRateUnit":charging_rate_unit
                }
            )

        elif connector_id == 2:
            f = open("status_limit0.txt", "r")
            status_limit0 = int(f.read())
            f = open("status_limit2.txt", "r")
            status_limit2 = int(f.read())
            if status_limit2 == 0 and status_limit0 == 0:
                limit = 150000
            elif (self.usiLinkStateCcs2 == 'Charging') and (self.iCpStateCss2 == 'Charging'):
                limit = float(limit/2)
            else:
                limit = limit

            return call_result.GetCompositeSchedulePayload(
                status = "Accepted",
                # status = GetCompositeScheduleStatus.accepted,
                connector_id = 2, #int
                schedule_start = convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)), #str
                charging_schedule = {
                    "duration": 0,
                    "chargingSchedulePeriod": [
                        {
                            "startPeriod": 0,
                            "numberPhases": 3,
                            "limit": limit
                        }
                    ],
                    "chargingRateUnit":charging_rate_unit
                }
            )

        else:
            return call_result.GetCompositeSchedulePayload(status = "Rejected")

    ############ Update 14-02-2568 22:35 END ############           

    @on(Action.GetConfiguration)
    async def on_get_configuration(self, **kwargs):
        full_configuration = [
            {
                'key': 'HeartbeatInterval',
                'readonly': False,
                'value': str(self.HeartbeatInterval_cfg)  # int, seconds
            },
            {
                'key': 'AuthorizationCacheEnabled',
                'readonly': False,
                'value': str(self.AuthorizationCacheEnabled_cfg)  # boolean
            },
            {
                'key': 'LocalAuthListEnabled',
                'readonly': False,
                'value': str(self.LocalAuthListEnabled_cfg)  # boolean
            },
            {
                'key': 'LocalAuthListMaxLength',
                'readonly': True,
                'value': str(self.LocalAuthListMaxLength_cfg)  # int
            },
            {
                'key': 'StopTxnSampledData',
                'readonly': False,  # CSL
                'value': str(self.StopTxnSampledData_cfg[0])
            },
            {
                'key': 'MeterValuesSampledData',
                'readonly': False,
                'value': str(self.MeterValuesSampledData_cfg)
            },
            {
                'key': 'AllowOfflineTxForUnknownId',
                'readonly': False,
                'value': str(self.AllowOfflineTxForUnknownId_cfg)
            },
            {
                'key': 'AuthorizeRemoteTxRequests',
                'readonly': False,  # CSL
                'value': str(self.AuthorizeRemoteTxRequests_cfg)
            },
            {
                'key': 'LocalAuthorizeOffline',
                'readonly': False,  # CSL
                'value': str(self.LocalAuthorizeOffline_cfg)
            },
            {
                'key': 'LocalPreAuthorize',
                'readonly': False,  # CSL
                'value': str(self.LocalPreAuthorize_cfg)
            },
            {
                'key': 'MeterValueSampleInterval',
                'readonly': False,  # CSL
                'value': str(self.MeterValueSampleInterval_cfg)
            },
            {
                'key': 'StopTransactionOnInvalidId',
                'readonly': False,  # CSL
                'value': str(self.StopTransactionOnInvalidId_cfg)
            },
        ]
        configuration_key = []
        try:
            print('## kwargs', kwargs['key'])
            for k in kwargs['key']:
                for item in full_configuration:
                    if k == item['key']:
                        config_dict = {
                            'key': k,
                            'readonly': item['readonly'],
                            'value': item['value']
                        }
                        configuration_key.append(config_dict)
        except:
            for item in full_configuration:
                config_dict = {
                    'key': item['key'],
                    'readonly': item['readonly'],
                    'value': item['value']
                }
                configuration_key.append(config_dict)

        return call_result.GetConfigurationPayload(
            configuration_key=configuration_key,
        )

    @on(Action.ChangeConfiguration)
    async def on_change_configuration(self, key, value, **kwargs):
        configurable_keys = ['HeartbeatInterval', 'LocalAuthListMaxLength', 'AuthorizationCacheEnabled',
                             'LocalAuthListEnabled',
                             'StopTxnSampledData', 'MeterValuesSampledData', 'AllowOfflineTxForUnknownId',
                             'AuthorizeRemoteTxRequests', 'LocalAuthorizeOffline', 'LocalPreAuthorize',
                             'MeterValueSampleInterval', 'StopTransactionOnInvalidId'
                             ]

        if key in configurable_keys:
            if key == 'HeartbeatInterval':
                self.HeartbeatInterval_cfg = value
                fw1 = open("HeartbeatInterval_cfg.txt", "w")
                fw1.write(str(self.HeartbeatInterval_cfg))
                fw1.close()

            elif key == 'LocalAuthListMaxLength':
                self.LocalAuthListMaxLength_cfg = value
                fw12 = open("LocalAuthListMaxLength.txt", "w")
                fw12.write(str(self.LocalAuthListMaxLength_cfg))
                fw12.close()

            elif key == 'AuthorizationCacheEnabled':
                self.AuthorizationCacheEnabled_cfg = value.lower() == 'true'
                fw2 = open("AuthorizationCacheEnabled_cfg.txt", "w")
                fw2.write(str(self.AuthorizationCacheEnabled_cfg))
                fw2.close()

            elif key == 'LocalAuthListEnabled':
                self.LocalAuthListEnabled_cfg = value
                fw3 = open("LocalAuthListEnabled_cfg.txt", "w")
                fw3.write(str(self.LocalAuthListEnabled_cfg))
                fw3.close()

            elif key == 'StopTxnSampledData':
                self.StopTxnSampledData_cfg = await self.change_configuration_stop_txn_sampled_data(value)
                fw4 = open("StopTxnSampledData_cfg.txt", "w")
                fw4.write(str(self.StopTxnSampledData_cfg))
                fw4.close()

            elif key == 'MeterValuesSampledData':
                self.MeterValuesSampledData_cfg = value
                fw5 = open("MeterValuesSampledData_cfg.txt", "w")
                fw5.write(str(self.MeterValuesSampledData_cfg))
                fw5.close()

            elif key == 'AllowOfflineTxForUnknownId':
                self.AllowOfflineTxForUnknownId_cfg = value
                fw6 = open("AllowOfflineTxForUnknownId_cfg.txt", "w")
                fw6.write(str(self.AllowOfflineTxForUnknownId_cfg))
                fw6.close()

            elif key == 'AuthorizeRemoteTxRequests':
                self.AuthorizeRemoteTxRequests_cfg = value
                fw7 = open("AuthorizeRemoteTxRequests_cfg.txt", "w")
                fw7.write(str(self.AuthorizeRemoteTxRequests_cfg))
                fw7.close()

            elif key == 'LocalAuthorizeOffline':
                self.LocalAuthorizeOffline_cfg = value
                fw8 = open("LocalAuthorizeOffline_cfg.txt", "w")
                fw8.write(str(self.LocalAuthorizeOffline_cfg))
                fw8.close()

            elif key == 'LocalPreAuthorize':
                self.LocalPreAuthorize_cfg = value
                fw9 = open("LocalPreAuthorize_cfg.txt", "w")
                fw9.write(str(self.LocalPreAuthorize_cfg))
                fw9.close()

            elif key == 'MeterValueSampleInterval':
                self.MeterValueSampleInterval_cfg = value
                fw10 = open("MeterValueSampleInterval_cfg.txt", "w")
                fw10.write(str(self.MeterValueSampleInterval_cfg))
                fw10.close()

            elif key == 'StopTransactionOnInvalidId':
                self.StopTransactionOnInvalidId_cfg = value
                fw11 = open("StopTransactionOnInvalidId_cfg.txt", "w")
                fw11.write(str(self.StopTransactionOnInvalidId_cfg))
                fw11.close()

            return call_result.ChangeConfigurationPayload(status='Accepted')
        else:
            return call_result.ChangeConfigurationPayload(status='Rejected')

    async def change_configuration_stop_txn_sampled_data(self, value: str):
        sampled_data = value.split(',')
        return sampled_data

    @on(Action.SendLocalList)
    async def on_send_local_list(self, local_authorization_list, **kwargs):
        update_type = kwargs['update_type']
        version_number = kwargs['list_version']
        if update_type == 'Full':
            self.local_auth_list.replace_list(local_authorization_list)
        else:  # Differential update
            for operation in local_authorization_list:
                identifier = operation['id_tag']
                status = operation['id_tag_info']['status']
                expiration_date = operation['id_tag_info'].get('expiration_date', None)
                self.local_auth_list.update(identifier, status, expiration_date)
        return call_result.SendLocalListPayload(status='Accepted')

    @on(Action.GetLocalListVersion)
    async def on_get_local_list_version(self, **kwargs):
        local_list_version = 0
        if local_list_version == 0:
            return call_result.GetLocalListVersionPayload(list_version=0)
        elif local_list_version == -1:
            return call_result.GetLocalListVersionPayload(list_version=-1)
        return call_result.GetLocalListVersionPayload(list_version=local_list_version)

    async def boot_notification_cp(self):  ## checked
        #line_notify('boot_PT_Sikhio1_1_150kW')
        request = call.BootNotificationPayload(
            charge_point_vendor="Flexxfast by EDS",
            charge_point_model="FD150A",
            firmware_version="V16072567a1_PLC_03122024",
        )
        response = await self.call(request)
        if response.status == 'Accepted':
            pass

    async def loss_network_regis(self):
        print(f" the number of transaction id 1 is  {len(str(self.transactionId_c1))}")
        print(f" the number of transaction id 2 is  {len(str(self.transactionId_c2))}")

        iCpStateCss1, usiLinkStateCcs1 = read_tag_status(self.myip_adr_c1)
        iCpStateCss2, usiLinkStateCcs2 = read_tag_status(self.myip_adr_c2)

        if (self.iCp1_regis == "Charging" and iCpStateCss1 != "Charging") and (
                self.usiLinkState1_regis == "Charging" and usiLinkStateCcs1 != "Charging") and len(
                str(self.transactionId_c1)) > 2:
            await self.send_meter_values(1)
            await self.send_stop_transaction(1, reasonf='PowerLoss')
        if (self.iCp2_regis == "Charging" and iCpStateCss2 != "Charging") or (
                self.usiLinkState2_regis == "Charging" and usiLinkStateCcs2 != "Charging") and len(
                str(self.transactionId_c2)) > 2:
            await self.send_meter_values(2)
            await self.send_stop_transaction(2, reasonf='PowerLoss')

    async def status_notification_cp(self, connector_id):  ## checked
        if connector_id == 1:
            self.iCpStateCss1, _ = read_tag_status(self.myip_adr_c1)
            request = call.StatusNotificationPayload(
                connector_id=1,
                error_code='NoError',
                status=self.iCpStateCss1,
                timestamp=convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)),
                vendor_id='EgatDimomdService',
            )
            await self.call(request)
        elif connector_id == 2:
            self.iCpStateCss2, _ = read_tag_status(self.myip_adr_c2)
            request = call.StatusNotificationPayload(
                connector_id=2,
                error_code='NoError',
                status=self.iCpStateCss2,
                timestamp=convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)),
                vendor_id='EgatDimomdService',
            )
            await self.call(request)

    async def status_notification_usiLink(self, connector_id):  ## checked
        if connector_id == 1:
            request = call.StatusNotificationPayload(
                connector_id=1,
                error_code='NoError',
                status='Finishing',
                timestamp=convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)),
                vendor_id='EgatDimomdService',
            )
            await self.call(request)
        elif connector_id == 2:
            request = call.StatusNotificationPayload(
                connector_id=2,
                error_code='NoError',
                status='Finishing',
                timestamp=convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)),
                vendor_id='EgatDimomdService',
            )
            await self.call(request)

    async def status_notification_emer(self, connector_id):  ## checked
        if connector_id == 1:
            request = call.StatusNotificationPayload(
                connector_id=1,
                error_code='NoError',
                status='Faulted',
                info='EmergencyButtonPressed',
                timestamp=convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)),
                vendor_id='EgatDimomdService',
            )
            await self.call(request)
        elif connector_id == 2:
            request = call.StatusNotificationPayload(
                connector_id=2,
                error_code='NoError',
                status='Faulted',
                info='EmergencyButtonPressed',
                timestamp=convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)),
                vendor_id='EgatDimomdService',
            )
            await self.call(request)

    async def send_heartbeat(self):  ## checked
        request = call.HeartbeatPayload()
        while True:
            await self.call(request)
            data = {
                    "heartbeat" : 1,
                    "timestamp" : datetime.now(pytz.timezone('Asia/Bangkok')).strftime("%Y-%m-%dT%H:%M:%S.%f")
                  }
            payload = json.dumps(data)
            client.publish(f"OCPP/{OCPPSTATION}/heartbeat", payload)
            await asyncio.sleep(int(self.HeartbeatInterval_cfg))

    @on(Action.RemoteStartTransaction)  ## checked
    async def remote_start_transaction(self, id_tag, connector_id, **kwargs):
        response = call_result.RemoteStartTransactionPayload(status=RemoteStartStopStatus.accepted)
        if response.status == RemoteStartStopStatus.accepted:

            if connector_id == 1:
                self.myremotestart_c1 = 1
                f = open("myremotestart_c1.txt", "w")
                f.write(str(self.myremotestart_c1))
                f.close()

                self.myid_tag_c1 = id_tag
                f = open("myid_tag_c1.txt", "w")
                f.write(str(self.myid_tag_c1))
                f.close()

            elif connector_id == 2:
                self.myremotestart_c2 = 1
                f = open("myremotestart_c2.txt", "w")
                f.write(str(self.myremotestart_c2))
                f.close()

                self.myid_tag_c2 = id_tag
                f = open("myid_tag_c2.txt", "w")
                f.write(str(self.myid_tag_c2))
                f.close()

        return response

    async def start_transaction(self, connector_id, **kwargs):  ## checked
        if connector_id == 1:
            self.meter_start1 = int(get_meter_value_pilot(self.my_meter_ip_c1)['energyTotal'] * 1000)  # Wh
            timestamp = convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc))
            request = call.StartTransactionPayload(
                connector_id=1,
                id_tag=self.myid_tag_c1,
                meter_start=self.meter_start1,
                timestamp=timestamp,
            )
            res = await self.call(request)

            self.transactionId_c1 = res.transaction_id
            f = open("translogs1.txt", "w")
            f.write(str(self.transactionId_c1))
            f.close()

        elif connector_id == 2:
            self.meter_start2 = int(get_meter_value_pilot(self.my_meter_ip_c2)['energyTotal'] * 1000)  # Wh
            timestamp = convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc))
            request = call.StartTransactionPayload(
                connector_id=2,
                id_tag=self.myid_tag_c2,
                meter_start=self.meter_start2,
                timestamp=timestamp,
            )
            res = await self.call(request)

            self.transactionId_c2 = res.transaction_id
            f = open("translogs2.txt", "w")
            f.write(str(self.transactionId_c2))
            f.close()

        else:
            print("## error line 482")

    async def start_transaction_ath(self, connector_id, **kwargs):
        if connector_id == 1:
            self.meter_start1 = int(get_meter_value_pilot(self.my_meter_ip_c1)['energyTotal'] * 1000)  # Wh
            timestamp = convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc))
            request = call.StartTransactionPayload(
                connector_id=1,
                id_tag=self.myid_tag_ath_c1,
                meter_start=self.meter_start1,
                timestamp=timestamp,
            )
            res = await self.call(request)
            self.transactionId_c1 = res.transaction_id
            f = open("translogs1.txt", "w")
            f.write(str(self.transactionId_c1))
            f.close()

            return res
        elif connector_id == 2:
            self.meter_start2 = int(get_meter_value_pilot(self.my_meter_ip_c2)['energyTotal'] * 1000)  # Wh
            timestamp = convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc))
            request = call.StartTransactionPayload(
                connector_id=2,
                id_tag=self.myid_tag_ath_c2,
                meter_start=self.meter_start2,
                timestamp=timestamp,
            )
            res = await self.call(request)

            self.transactionId_c2 = res.transaction_id
            f = open("translogs2.txt", "w")
            f.write(str(self.transactionId_c2))
            f.close()

            return res
        else:
            print("## error line 514")

    @on(Action.RemoteStopTransaction)  ## checked
    async def remote_stop_transaction(self, transaction_id, **kwargs):
        if transaction_id == self.transactionId_c1:
            response = call_result.RemoteStopTransactionPayload(status=RemoteStartStopStatus.accepted)
            if response.status == RemoteStartStopStatus.accepted:
                self.my_remote_stop_c1 = 1
                f = open("my_remote_stop_c1.txt", "w")
                f.write(str(self.my_remote_stop_c1))
                f.close()

            return response
        elif transaction_id == self.transactionId_c2:
            response = call_result.RemoteStopTransactionPayload(status=RemoteStartStopStatus.accepted)
            if response.status == RemoteStartStopStatus.accepted:
                self.my_remote_stop_c2 = 1
                f = open("my_remote_stop_c2.txt", "w")
                f.write(str(self.my_remote_stop_c2))
                f.close()

            return response
        else:
            print("## error line 529")

    async def send_stop_transaction(self, connector_id, reasonf, **kwargs):  ## checked
        if connector_id == 1:

            self.meter_stop1 = int(get_meter_value_pilot(self.my_meter_ip_c1)['energyTotal'] * 1000)
            timestamp = convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc))
            self.timestamp1 = datetime.now(pytz.timezone('Asia/Bangkok')).strftime("%Y-%m-%dT%H:%M:%S.%f")
            data = {
                "meter1" : self.meter_stop1,
                "meter2" : self.meter_stop2,
                "timestamp1" : self.timestamp1,
                "timestamp2" : self.timestamp2,
                "timestamp" : timestamp
            }
            payload = json.dumps(data)
            client.publish(f"OCPP/{OCPPSTATION}/meter",payload)

            if self.StopTxnSampledData_cfg[0] == '0':
                request = call.StopTransactionPayload(
                    meter_stop=self.meter_stop1,
                    timestamp=timestamp,
                    transaction_id=self.transactionId_c1,
                    id_tag=self.myid_tag_c1,
                    reason=reasonf,
                    transaction_data=None
                )
            else:
                live_data = get_livemeasure_pilot(self.my_meter_ip_c1)
                voltage, current = live_data['voltage'], live_data['current']
                energyImport = live_data['energyTotal']  # kWh
                power = live_data['power']  # kW
                soc = get_soc(self.myip_adr_c1)  # %
                x = {
                    'Voltage': {'measurand': "Voltage", 'unit': 'V', 'value': str(voltage)},
                    'Current.Import': {'measurand': 'Current.Import', 'unit': 'A', 'value': str(current)},
                    'Energy.Active.Import.Register': {'measurand': 'Energy.Active.Import.Register', 'unit': 'kWh',
                                                      'value': str(energyImport)},
                    'Power.Active.Import': {'measurand': 'Power.Active.Import', 'unit': 'kW', 'value': str(power)},
                    'SoC': {'measurand': 'SoC', 'unit': 'Percent', 'value': str(soc)},
                    'Power.Offered': {'measurand': 'Power.Offered', 'unit': 'kW', 'value': '150'},
                    'Current.Offered': {'measurand': 'Current.Offered', 'unit': 'A', 'value': '500'}
                }
                sampledValue = []
                for y in self.StopTxnSampledData_cfg:
                    if y in x:
                        sampledValue.append(x[y])
                request = call.StopTransactionPayload(
                    meter_stop=self.meter_stop1,
                    timestamp=timestamp,
                    transaction_id=self.transactionId_c1,
                    id_tag=self.myid_tag_c1,
                    reason=reasonf,
                    transaction_data=[
                        {
                            'timestamp': convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)),
                            'sampledValue': sampledValue
                        }
                    ]
                )
            await self.call(request)
        elif connector_id == 2:

            self.meter_stop2 = int(get_meter_value_pilot(self.my_meter_ip_c2)['energyTotal'] * 1000)
            timestamp = convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc))
            self.timestamp2 = datetime.now(pytz.timezone('Asia/Bangkok')).strftime("%Y-%m-%dT%H:%M:%S.%f")
            data = {
                "meter1" : self.meter_stop1,
                "meter2" : self.meter_stop2,
                "timestamp1" : self.timestamp1,
                "timestamp2" : self.timestamp2,
                "timestamp" : timestamp
            }
            payload = json.dumps(data)
            client.publish(f"OCPP/{OCPPSTATION}/meter",payload)


            if self.StopTxnSampledData_cfg[0] == '0':
                request = call.StopTransactionPayload(
                    meter_stop=self.meter_stop2,
                    timestamp=timestamp,
                    transaction_id=self.transactionId_c2,
                    id_tag=self.myid_tag_c2,
                    reason=reasonf,
                    transaction_data=None
                )
            else:
                live_data = get_livemeasure_pilot(self.my_meter_ip_c2)
                voltage, current = live_data['voltage'], live_data['current']
                energyImport = live_data['energyTotal']  # kWh
                power = live_data['power']  # kW
                soc = get_soc(self.myip_adr_c2)  # %
                x = {
                    'Voltage': {'measurand': "Voltage", 'unit': 'V', 'value': str(voltage)},
                    'Current.Import': {'measurand': 'Current.Import', 'unit': 'A', 'value': str(current)},
                    'Energy.Active.Import.Register': {'measurand': 'Energy.Active.Import.Register', 'unit': 'kWh',
                                                      'value': str(energyImport)},
                    'Power.Active.Import': {'measurand': 'Power.Active.Import', 'unit': 'kW', 'value': str(power)},
                    'SoC': {'measurand': 'SoC', 'unit': 'Percent', 'value': str(soc)},
                    'Power.Offered': {'measurand': 'Power.Offered', 'unit': 'kW', 'value': '150'},
                    'Current.Offered': {'measurand': 'Current.Offered', 'unit': 'A', 'value': '500'}
                }
                sampledValue = []
                for y in self.StopTxnSampledData_cfg:
                    if y in x:
                        sampledValue.append(x[y])
                request = call.StopTransactionPayload(
                    meter_stop=self.meter_stop2,
                    timestamp=timestamp,
                    transaction_id=self.transactionId_c2,
                    id_tag=self.myid_tag_c2,
                    reason=reasonf,
                    transaction_data=[
                        {
                            'timestamp': convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)),
                            'sampledValue': sampledValue
                        }
                    ]
                )
            await self.call(request)

    async def send_meter_values(self, connector_id):  ## checked
        if connector_id == 1:
            f = open("translogs1.txt", "r")
            self.transactionId_c1 = int(f.read())
            live_data = get_livemeasure_pilot(self.my_meter_ip_c1)
            voltage, current = live_data['voltage'], live_data['current']
            energyImport = live_data['energyTotal']  # kWh

            power = live_data['power']  # kW
            soc = get_soc(self.myip_adr_c1)  # %
            
            f = open("limit.txt", "r")
            limit = int(f.read())
            f = open("status_limit0.txt", "r")
            status_limit0 = int(f.read())
            f = open("status_limit1.txt", "r")
            status_limit1 = int(f.read())       

            if status_limit1 == 0 and status_limit0 == 0:
                limit = 150000
            elif (self.usiLinkStateCcs1 == 'Charging') and (self.iCpStateCss1 == 'Charging'):
                limit = float(limit/2)
            else:
                limit = limit            
            
            #if self.MeterValuesSampledData_cfg.split(', ') == 7:
            if (len(self.MeterValuesSampledData_cfg.split(',')) == 6) or (len(self.MeterValuesSampledData_cfg.split(',')) == 7):
            
                request = call.MeterValuesPayload(
                    connector_id=connector_id,
                    transaction_id=int(self.transactionId_c1),
                    meter_value=
                    [
                        {
                            'timestamp': convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)),
                            'sampledValue':
                                [
                                    {'measurand': "Voltage", 'unit': 'V', 'value': str(voltage)},
                                    {'measurand': 'Current.Import', 'unit': 'A', 'value': str(current)},
                                    {'measurand': 'Energy.Active.Import.Register', 'unit': 'kWh',
                                     'value': str(energyImport)},
                                    {'measurand': 'Power.Active.Import', 'unit': 'kW', 'value': str(power)},
                                    {'measurand': 'SoC', 'unit': 'Percent', 'value': str(soc)},
                                    {'measurand': 'Power.Offered', 'unit': 'kW', 'value': str(int(limit/1000))},
                                    {'measurand': 'Current.Offered', 'unit': 'A', 'value': str(int(current))},
                                ]
                        }
                    ]

                )
                await self.call(request)
            else:
                s1 = self.MeterValuesSampledData_cfg.split(', ')
                item_list = []
                cdict = {
                    'Voltage': {'unit': 'V', 'value': str(voltage)},
                    'Current.Import': {'unit': 'A', 'value': str(current)},
                    'Energy.Active.Import.Register': {'unit': 'kWh', 'value': str(energyImport)},
                    'Power.Active.Import': {'unit': 'kW', 'value': str(power)},
                    'SoC': {'unit': 'Percent', 'value': str(soc)},
                    'Power.Offered': {'unit': 'kW', 'value': str(int(limit/1000))},
                    'Current.Offered': {'unit': 'A', 'value': str(int(current))},
                }
                for val_item in s1:
                    item_list.append(
                        {'measurand': val_item, 'unit': cdict[val_item]['unit'], 'value': cdict[val_item]['value']})

                request = call.MeterValuesPayload(
                    connector_id=connector_id,
                    transaction_id=int(self.transactionId_c1),
                    meter_value=
                    [
                        {
                            'timestamp': convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)),
                            'sampledValue': item_list
                        }
                    ]
                )
                await self.call(request)

        elif connector_id == 2:
            f = open("translogs2.txt", "r")
            self.transactionId_c2 = int(f.read())
            live_data = get_livemeasure_pilot(self.my_meter_ip_c2)
            voltage, current = live_data['voltage'], live_data['current']
            energyImport = live_data['energyTotal']  # kWh

            power = live_data['power']  # kW
            soc = get_soc(self.myip_adr_c2)  # %
            
            f = open("limit.txt", "r")
            limit = int(f.read())
            f = open("status_limit0.txt", "r")
            status_limit0 = int(f.read())
            f = open("status_limit2.txt", "r")
            status_limit2 = int(f.read())
            
            if status_limit2 == 0 and status_limit0 == 0:
                limit = 150000
            elif (self.usiLinkStateCcs2 == 'Charging') and (self.iCpStateCss2 == 'Charging'):
                limit = float(limit/2)
            else:
                limit = limit            

            #if self.MeterValuesSampledData_cfg.split(', ') == 7:
            if (len(self.MeterValuesSampledData_cfg.split(',')) == 6) or (len(self.MeterValuesSampledData_cfg.split(',')) == 7):
            
                request = call.MeterValuesPayload(
                    connector_id=connector_id,
                    transaction_id=int(self.transactionId_c2),
                    meter_value=
                    [
                        {
                            'timestamp': convert_timeformat(
                                datetime.now(timezone.utc).replace(tzinfo=timezone.utc)),
                            'sampledValue':
                                [
                                    {'measurand': "Voltage", 'unit': 'V', 'value': str(voltage)},
                                    {'measurand': 'Current.Import', 'unit': 'A', 'value': str(current)},
                                    {'measurand': 'Energy.Active.Import.Register', 'unit': 'kWh',
                                     'value': str(energyImport)},
                                    {'measurand': 'Power.Active.Import', 'unit': 'kW', 'value': str(power)},
                                    {'measurand': 'SoC', 'unit': 'Percent', 'value': str(soc)},
                                    {'measurand': 'Power.Offered', 'unit': 'kW', 'value': str(int(limit/1000))},
                                    {'measurand': 'Current.Offered', 'unit': 'A', 'value': str(int(current))},
                                ]
                        }
                    ]
                )
                await self.call(request)
            else:
                s1 = self.MeterValuesSampledData_cfg.split(', ')
                item_list = []
                cdict = {
                    'Voltage': {'unit': 'V', 'value': str(voltage)},
                    'Current.Import': {'unit': 'A', 'value': str(current)},
                    'Energy.Active.Import.Register': {'unit': 'kWh', 'value': str(energyImport)},
                    'Power.Active.Import': {'unit': 'kW', 'value': str(power)},
                    'SoC': {'unit': 'Percent', 'value': str(soc)},
                    'Power.Offered': {'unit': 'kW', 'value': str(int(limit/1000))},
                    'Current.Offered': {'unit': 'A', 'value': str(int(current))},
                }
                for val_item in s1:
                    item_list.append(
                        {'measurand': val_item, 'unit': cdict[val_item]['unit'], 'value': cdict[val_item]['value']})
                request = call.MeterValuesPayload(
                    connector_id=connector_id,
                    transaction_id=int(self.transactionId_c2),
                    meter_value=
                    [
                        {
                            'timestamp': convert_timeformat(datetime.now(timezone.utc).replace(tzinfo=timezone.utc)),
                            'sampledValue': item_list
                        }
                    ]
                )
                await self.call(request)

    @on(Action.Reset)  ## checked
    async def hard_Reset(self, **kwargs):
        print(f"## kwargs: {kwargs}")
        if kwargs['type'] == 'Soft':
            print('Soft Reset')
            os.system("sudo reboot")
        else:
            print('Hard Reset')
            res1 = read_OCPP_HardReset1(self.myip_adr_c1, 1)
            res2 = read_OCPP_HardReset1(self.myip_adr_c2, 1)
            time.sleep(10)
            os.system("sudo reboot")
        return call_result.ResetPayload(status='Accepted')

    async def main_run_program(self, interval):
        while (1):

            iCpStateCss1, usiLinkStateCcs1 = read_tag_status(self.myip_adr_c1)
            iCpStateCss2, usiLinkStateCcs2 = read_tag_status(self.myip_adr_c2)

            ### Remote Start connector 1 ## checked
            if self.start_trans_SW_c1 == 1:
                if self.myremotestart_c1 == 1:
                    x = remote_start_plc(self.myip_adr_c1, 1)
                    print(f"## rising edge: {x}")
                    time.sleep(2)
                    res = remote_start_plc(self.myip_adr_c1, 0)
                    print(f"## falling edge: {res}")

                    self.start_transaction_SW1 = 3
                    fw1 = open("start_transaction_SW1.txt", "w")
                    fw1.write(str(self.start_transaction_SW1))
                    fw1.close()

                    self.myremotestart_c1 = 0
                    f = open("myremotestart_c1.txt", "w")
                    f.write(str(self.myremotestart_c1))
                    f.close()

                    self.start_trans_SW_c1 = 2
                    fw1 = open("start_trans_SW_c1.txt", "w")
                    fw1.write(str(self.start_trans_SW_c1))
                    fw1.close()

            else:
                if self.myremotestart_c1 == 0:
                    self.start_trans_SW_c1 = 1
                    fw1 = open("start_trans_SW_c1.txt", "w")
                    fw1.write(str(self.start_trans_SW_c1))
                    fw1.close()

            ### Remote Start connector 2 ## checked
            if self.start_trans_SW_c2 == 1:
                if self.myremotestart_c2 == 1:
                    x = remote_start_plc(self.myip_adr_c2, 1)
                    print(f"## rising edge: {x}")
                    time.sleep(2)
                    res = remote_start_plc(self.myip_adr_c2, 0)
                    print(f"## falling edge: {res}")

                    self.start_transaction_SW2 = 3
                    fw1 = open("start_transaction_SW2.txt", "w")
                    fw1.write(str(self.start_transaction_SW2))
                    fw1.close()

                    self.myremotestart_c2 = 0
                    f = open("myremotestart_c2.txt", "w")
                    f.write(str(self.myremotestart_c2))
                    f.close()

                    self.start_trans_SW_c2 = 2
                    fw1 = open("start_trans_SW_c2.txt", "w")
                    fw1.write(str(self.start_trans_SW_c2))
                    fw1.close()

            else:
                if self.myremotestart_c2 == 0:
                    self.start_trans_SW_c2 = 1
                    fw1 = open("start_trans_SW_c2.txt", "w")
                    fw1.write(str(self.start_trans_SW_c2))
                    fw1.close()

            ## update usiLink state connector id 1-2 ## checked
            if self.usiLinkStateCcs1 != usiLinkStateCcs1:
                self.usiLinkStateCcs1 = usiLinkStateCcs1
                fw1 = open("usiLinkState1_regis.txt", "w")
                fw1.write(str(self.usiLinkStateCcs1))
                fw1.close()
            if self.usiLinkStateCcs2 != usiLinkStateCcs2:
                self.usiLinkStateCcs2 = usiLinkStateCcs2
                fw1 = open("usiLinkState2_regis.txt", "w")
                fw1.write(str(self.usiLinkStateCcs2))
                fw1.close()

            if iCpStateCss1 in ['Available', 'Preparing', 'Charging']:
                self.iCpStateCss1 = iCpStateCss1
                if self.emergency_sent_c1 == '0':
                    if (self.iCpStateCss1 == 'Available') and (self.block_sw1_C1 == 1):
                        if finish_one_c1(self.myip_adr_c1) == '1':
                            pass
                        else:
                            await self.status_notification_cp(1)
                            self.block_sw1_C1 = 0
                            self.block_sw2_C1 = 1
                            self.block_sw3_C1 = 1
                            
                            fw = open("iCpStateCss1.txt", "w")
                            fw.write(str(self.iCpStateCss1))
                            fw.close()
                            
                            fw = open("block_sw1_C1.txt", "w")
                            fw.write(str(self.block_sw1_C1))
                            fw.close()   
                            fw = open("block_sw2_C1.txt", "w")
                            fw.write(str(self.block_sw2_C1))
                            fw.close()     
                            fw = open("block_sw3_C1.txt", "w")
                            fw.write(str(self.block_sw3_C1))
                            fw.close()                             
                        
                    elif (self.iCpStateCss1 == 'Preparing') and (self.block_sw2_C1 == 1):
                        if finish_one_c1(self.myip_adr_c1) == '1':
                            pass
                        else:                    
                            await self.status_notification_cp(1)
                            self.block_sw1_C1 = 1
                            self.block_sw2_C1 = 0
                            self.block_sw3_C1 = 1
                            
                            fw = open("iCpStateCss1.txt", "w")
                            fw.write(str(self.iCpStateCss1))
                            fw.close()
                            
                            fw = open("block_sw1_C1.txt", "w")
                            fw.write(str(self.block_sw1_C1))
                            fw.close()   
                            fw = open("block_sw2_C1.txt", "w")
                            fw.write(str(self.block_sw2_C1))
                            fw.close()     
                            fw = open("block_sw3_C1.txt", "w")
                            fw.write(str(self.block_sw3_C1))
                            fw.close()    
                        
                    elif (self.iCpStateCss1 == 'Charging') and (self.block_sw3_C1 == 1):
                        if finish_one_c1(self.myip_adr_c1) == '1':
                            pass
                        else:                    
                            await self.status_notification_cp(1)
                            self.block_sw1_C1 = 1
                            self.block_sw2_C1 = 1
                            self.block_sw3_C1 = 0
                            
                            fw = open("iCpStateCss1.txt", "w")
                            fw.write(str(self.iCpStateCss1))
                            fw.close()
                            
                            fw = open("block_sw1_C1.txt", "w")
                            fw.write(str(self.block_sw1_C1))
                            fw.close()   
                            fw = open("block_sw2_C1.txt", "w")
                            fw.write(str(self.block_sw2_C1))
                            fw.close()     
                            fw = open("block_sw3_C1.txt", "w")
                            fw.write(str(self.block_sw3_C1))
                            fw.close()  
                        
                    else:
                        pass

            if iCpStateCss2 in ['Available', 'Preparing', 'Charging']:
                self.iCpStateCss2 = iCpStateCss2
                if self.emergency_sent_c2 == '0':
                    if (self.iCpStateCss2 == 'Available') and (self.block_sw1 == 1):
                        if finish_one_c2(self.myip_adr_c2) == '1':
                            pass
                        else:                         
                            await self.status_notification_cp(2)
                            self.block_sw1 = 0
                            self.block_sw2 = 1
                            self.block_sw3 = 1
                            
                            fw = open("iCpStateCss2.txt", "w")
                            fw.write(str(self.iCpStateCss2))
                            fw.close()
                            
                            fw = open("block_sw1.txt", "w")
                            fw.write(str(self.block_sw1))
                            fw.close()   
                            fw = open("block_sw2.txt", "w")
                            fw.write(str(self.block_sw2))
                            fw.close()     
                            fw = open("block_sw3.txt", "w")
                            fw.write(str(self.block_sw3))
                            fw.close() 
                        
                    elif (self.iCpStateCss2 == 'Preparing') and (self.block_sw2 == 1):
                        if finish_one_c2(self.myip_adr_c2) == '1':
                            pass
                        else:                         
                            await self.status_notification_cp(2)
                            self.block_sw1 = 1
                            self.block_sw2 = 0
                            self.block_sw3 = 1
                            
                            fw = open("iCpStateCss2.txt", "w")
                            fw.write(str(self.iCpStateCss2))
                            fw.close()
                            
                            fw = open("block_sw1.txt", "w")
                            fw.write(str(self.block_sw1))
                            fw.close()   
                            fw = open("block_sw2.txt", "w")
                            fw.write(str(self.block_sw2))
                            fw.close()     
                            fw = open("block_sw3.txt", "w")
                            fw.write(str(self.block_sw3))
                            fw.close() 
                        
                    elif (self.iCpStateCss2 == 'Charging') and (self.block_sw3 == 1):
                        if finish_one_c2(self.myip_adr_c2) == '1':
                            pass
                        else:                         
                            await self.status_notification_cp(2)
                            self.block_sw1 = 1
                            self.block_sw2 = 1
                            self.block_sw3 = 0
                            
                            fw = open("iCpStateCss2.txt", "w")
                            fw.write(str(self.iCpStateCss2))
                            fw.close()
                            
                            fw = open("block_sw1.txt", "w")
                            fw.write(str(self.block_sw1))
                            fw.close()   
                            fw = open("block_sw2.txt", "w")
                            fw.write(str(self.block_sw2))
                            fw.close()     
                            fw = open("block_sw3.txt", "w")
                            fw.write(str(self.block_sw3))
                            fw.close() 
                    else:
                        pass
                        
            ## Remote stop connector id 1 ## checked
            if self.my_remote_stop_c1 == 1:
                remote_stop_plc(self.myip_adr_c1, 1)
                time.sleep(3)
                remote_stop_plc(self.myip_adr_c1, 0)

                self.my_remote_stop_c1 = 0
                f = open("my_remote_stop_c1.txt", "w")
                f.write(str(self.my_remote_stop_c1))
                f.close()

                self.block1 = 1
                f = open("block1.txt", "w")
                f.write(str(self.block1))
                f.close()

            ## Remote stop connector id 2 ## checked
            if self.my_remote_stop_c2 == 1:
                remote_stop_plc(self.myip_adr_c2, 1)
                time.sleep(3)
                remote_stop_plc(self.myip_adr_c2, 0)

                self.my_remote_stop_c2 = 0
                f = open("my_remote_stop_c2.txt", "w")
                f.write(str(self.my_remote_stop_c2))
                f.close()

                self.block2 = 1
                f = open("block2.txt", "w")
                f.write(str(self.block2))
                f.close()

            ## Local Stop connector id 1 ## checked
            self.finshing_sent_c1 = Head1Finishing(self.myip_adr_c1)
            if self.finshing_sent_c1 == '1':
                print(f"### self.finshing_sent_c1: {self.finshing_sent_c1}")
            if self.finshing_sent_sw_c1 == 1:
                if self.finshing_sent_c1 == '1':
                    if self.block1 == 1:
                        await self.status_notification_usiLink(1)
                        f = open("translogs1.txt", "r")
                        self.transactionId_c1 = int(f.read())
                        await self.send_stop_transaction(1, reasonf='Remote')
                        print("## send_stop_transaction 1 Remote")

                        self.finshing_sent_sw_c1 = 2
                        f = open("finshing_sent_sw_c1.txt", "w")
                        f.write(str(self.finshing_sent_sw_c1))
                        f.close()

                        ## Clear Transaction ID
                        f = open("translogs1.txt", "w")
                        f.write(str(0))
                        f.close()

                    elif self.block1 == 0:
                        await self.status_notification_usiLink(1)
                        f = open("translogs1.txt", "r")
                        self.transactionId_c1 = int(f.read())
                        await self.send_stop_transaction(1, reasonf='Local')
                        print("## send_stop_transaction 1 Local")

                        self.finshing_sent_sw_c1 = 2
                        f = open("finshing_sent_sw_c1.txt", "w")
                        f.write(str(self.finshing_sent_sw_c1))
                        f.close()

                        ## Clear Transaction ID
                        f = open("translogs1.txt", "w")
                        f.write(str(0))
                        f.close()

                    self.finshing_sent_sw_c1 = 2
                    f = open("finshing_sent_sw_c1.txt", "w")
                    f.write(str(self.finshing_sent_sw_c1))
                    f.close()

                else:
                    pass
            else:
                if self.finshing_sent_c1 == '0':

                    self.finshing_sent_sw_c1 = 1
                    f = open("finshing_sent_sw_c1.txt", "w")
                    f.write(str(self.finshing_sent_sw_c1))
                    f.close()

                    self.block1 = 0
                    f = open("block1.txt", "w")
                    f.write(str(self.block1))
                    f.close()

                else:
                    pass

            ### Remote Stop connector id 2 ## checked
            self.finshing_sent_c2 = Head2Finishing(self.myip_adr_c2)
            if self.finshing_sent_c2 == '1':
                print(f"### self.finshing_sent_c2: {self.finshing_sent_c2}")
            if self.finshing_sent_sw_c2 == 1:
                if self.finshing_sent_c2 == '1':
                    if self.block2 == 1:
                        await self.status_notification_usiLink(2)
                        f = open("translogs2.txt", "r")
                        self.transactionId_c2 = int(f.read())
                        await self.send_stop_transaction(2, reasonf='Remote')
                        print("## send_stop_transaction 2 Remote")

                        self.finshing_sent_sw_c2 = 2
                        f = open("finshing_sent_sw_c2.txt", "w")
                        f.write(str(self.finshing_sent_sw_c2))
                        f.close()

                        self.block2 = 0
                        f = open("block2.txt", "w")
                        f.write(str(self.block2))
                        f.close()

                        ## Clear Transaction ID
                        f = open("translogs2.txt", "w")
                        f.write(str(0))
                        f.close()

                    elif self.block2 == 0:
                        await self.status_notification_usiLink(2)
                        f = open("translogs2.txt", "r")
                        self.transactionId_c2 = int(f.read())
                        await self.send_stop_transaction(2, reasonf='Local')
                        print("## send_stop_transaction 2 Local")

                        self.finshing_sent_sw_c2 = 2
                        f = open("finshing_sent_sw_c2.txt", "w")
                        f.write(str(self.finshing_sent_sw_c2))
                        f.close()

                        ## Clear Transaction ID
                        f = open("translogs2.txt", "w")
                        f.write(str(0))
                        f.close()

                    self.finshing_sent_sw_c2 = 2
                    f = open("finshing_sent_sw_c2.txt", "w")
                    f.write(str(self.finshing_sent_sw_c2))
                    f.close()

                else:
                    pass
            else:
                if self.finshing_sent_c2 == '0':
                    self.finshing_sent_sw_c2 = 1
                    f = open("finshing_sent_sw_c2.txt", "w")
                    f.write(str(self.finshing_sent_sw_c2))
                    f.close()

                    self.block2 = 0
                    f = open("block2.txt", "w")
                    f.write(str(self.block2))
                    f.close()
                else:
                    pass

            # ## authorize connector id 1 ## checked
            # authorize1 = read_tag_read1(self.myip_adr_c1)
            # len_authorize1 = len(authorize1)
            #
            # if len_authorize1 > 2:
            #
            #     self.myid_tag_ath_c1 = authorize1
            #     f = open("myid_tag_ath_c1.txt", "w")
            #     f.write(str(self.myid_tag_ath_c1))
            #     f.close()
            #
            #     if (self.myid_tag_ath_c1 == self.accepted_tag1) and (iCpStateCss1 == 'Charging'):
            #         print("##### accepted_tag1", self.accepted_tag1)
            #         remote_stop_plc(self.myip_adr_c1, 1)
            #         time.sleep(3)
            #         remote_stop_plc(self.myip_adr_c1, 0)
            #         self.accepted_tag1 = '0'
            #
            #     elif (iCpStateCss1 == 'Preparing') and (usiLinkStateCcs1 == 'Available'):
            #         res = await self.authorize(self.myid_tag_ath_c1)
            #         try:
            #             print('## authorize response:', res)
            #             if res.id_tag_info['status'] == 'Accepted':
            #                 self.accepted_tag1 = self.myid_tag_ath_c1
            #                 if self.transactionId_c1 == -1:
            #                     print(f"## transactionId=-1: status: Expired {res_start.id_tag_info['status']}")
            #                 else:
            #                     x = remote_start_plc(self.myip_adr_c1, 1)
            #                     print(f"## rising edge: {x}")
            #                     time.sleep(2)
            #                     res = remote_start_plc(self.myip_adr_c1, 0)
            #                     print(f"## falling edge: {res}")
            #                     self.start_transaction_SW1 = 1
            #
            #                     fw1 = open("start_transaction_SW1.txt", "w")
            #                     fw1.write(str(self.start_transaction_SW1))
            #                     fw1.close()
            #
            #                     self.block1 = 0
            #                     f = open("block1.txt", "w")
            #                     f.write(str(self.block1))
            #                     f.close()
            #             else:
            #                 print("## Card Invilid")
            #         except Exception as e:
            #             print(f"## error line 954 {e}")
            #             print("## no response null")
            #     else:
            #         print("wrong rfid1")
            # else:
            #     pass

            # ## authorize connector id 2 ## checked
            # authorize2 = read_tag_read2(self.myip_adr_c2)
            # len_authorize2 = len(authorize2)
            #
            # if len_authorize2 > 2:
            #     self.myid_tag_ath_c2 = authorize2
            #     f = open("myid_tag_ath_c2.txt", "w")
            #     f.write(str(self.myid_tag_ath_c2))
            #     f.close()
            #
            #     if (self.myid_tag_ath_c2 == self.accepted_tag2) and (iCpStateCss2 == 'Charging'):
            #         print("##### accepted_tag2", self.accepted_tag2)
            #         remote_stop_plc(self.myip_adr_c2, 1)
            #         time.sleep(3)
            #         remote_stop_plc(self.myip_adr_c2, 0)
            #         self.accepted_tag2 = '0'
            #
            #     elif (iCpStateCss2 == 'Preparing') and (usiLinkStateCcs2 == 'Available'):
            #         res = await self.authorize(self.myid_tag_ath_c2)
            #         try:
            #             print('## authorize response:', res)
            #             if res.id_tag_info['status'] == 'Accepted':
            #                 self.accepted_tag2 = self.myid_tag_ath_c2
            #                 if self.transactionId_c2 == -1:
            #                     print(f"## transactionId=-1: status: Expired {res_start.id_tag_info['status']}")
            #                 else:
            #                     x = remote_start_plc(self.myip_adr_c2, 1)
            #                     print(f"## rising edge: {x}")
            #                     time.sleep(2)
            #                     res = remote_start_plc(self.myip_adr_c2, 0)
            #                     print(f"## falling edge: {res}")
            #
            #                     self.start_transaction_SW2 = 1
            #                     f = open("start_transaction_SW2.txt", "w")
            #                     f.write(str(self.start_transaction_SW2))
            #                     f.close()
            #
            #                     self.block2 = 0
            #                     f = open("block2.txt", "w")
            #                     f.write(str(self.block2))
            #                     f.close()
            #             else:
            #                 print("## Card Invilid")
            #         except Exception as e:
            #             print(f"## error line 979 {e}")
            #             print("## no response null")
            #     else:
            #         print("wrong rfid2")
            # else:
            #     pass

            ## Start Transaction 1
            if self.start_transaction_SW1 == 1:
                if self.usiLinkStateCcs1 == 'Charging' and self.iCpStateCss1 == 'Charging' and self.start_transaction_SW1 != 2:
                    res_start = await self.start_transaction_ath(1)

                    self.start_transaction_SW1 = 2
                    fw1 = open("start_transaction_SW1.txt", "w")
                    fw1.write(str(self.start_transaction_SW1))
                    fw1.close()

                    self.start_sendMeterValue_SW1 = 2
                    fw1 = open("start_sendMeterValue_SW1.txt", "w")
                    fw1.write(str(self.start_sendMeterValue_SW1))
                    fw1.close()

            ## Remote Transaction 1
            if self.start_transaction_SW1 == 3:
                if self.usiLinkStateCcs1 == 'Charging' and self.iCpStateCss1 == 'Charging' and self.start_transaction_SW1 != 4:
                    res_start = await self.start_transaction(1)

                    self.start_transaction_SW1 = 4
                    fw1 = open("start_transaction_SW1.txt", "w")
                    fw1.write(str(self.start_transaction_SW1))
                    fw1.close()

                    self.start_sendMeterValue_SW1 = 2
                    fw1 = open("start_sendMeterValue_SW1.txt", "w")
                    fw1.write(str(self.start_sendMeterValue_SW1))
                    fw1.close()

            ## Start Transaction 2
            if self.start_transaction_SW2 == 1:
                if self.usiLinkStateCcs2 == 'Charging' and self.iCpStateCss2 == 'Charging' and self.start_transaction_SW2 != 2:
                    res_start = await self.start_transaction_ath(2)

                    self.start_transaction_SW2 = 2
                    fw1 = open("start_transaction_SW2.txt", "w")
                    fw1.write(str(self.start_transaction_SW2))
                    fw1.close()

                    self.start_sendMeterValue_SW2 = 2
                    fw1 = open("start_sendMeterValue_SW2.txt", "w")
                    fw1.write(str(self.start_sendMeterValue_SW2))
                    fw1.close()

            ## Remote Transaction 2
            if self.start_transaction_SW2 == 3:
                if self.usiLinkStateCcs2 == 'Charging' and self.iCpStateCss2 == 'Charging' and self.start_transaction_SW2 != 4:
                    res_start = await self.start_transaction(2)

                    self.start_transaction_SW2 = 4
                    fw1 = open("start_transaction_SW2.txt", "w")
                    fw1.write(str(self.start_transaction_SW2))
                    fw1.close()

                    self.start_sendMeterValue_SW2 = 2
                    fw1 = open("start_sendMeterValue_SW2.txt", "w")
                    fw1.write(str(self.start_sendMeterValue_SW2))
                    fw1.close()

            if (self.start_sendMeterValue_SW1 == 2) or (self.start_sendMeterValue_SW2 == 2):
                ## sent meter value connector id 1-2 when charging ## checked
                if ((self.usiLinkStateCcs1 == 'Charging') and (self.iCpStateCss1 == 'Charging')) and (
                        self.my_remote_stop_c1 == 0) and (
                        ((self.usiLinkStateCcs2 == 'Available') or (self.usiLinkStateCcs2 == 'Preparing')) or (
                        self.finshing_sent_c2 == '1')):
                    await self.send_meter_values(1)
                    time.sleep(4)
                if ((self.usiLinkStateCcs2 == 'Charging') and (self.iCpStateCss2 == 'Charging')) and (
                        self.my_remote_stop_c2 == 0) and (
                        ((self.usiLinkStateCcs1 == 'Available') or (self.usiLinkStateCcs1 == 'Preparing')) or (
                        self.finshing_sent_c1 == '1')):
                    await self.send_meter_values(2)
                    time.sleep(4)
                if ((self.usiLinkStateCcs1 == 'Charging') and (self.iCpStateCss1 == 'Charging')) and (
                        (self.usiLinkStateCcs2 == 'Charging') and (self.iCpStateCss2 == 'Charging')) and (
                        self.my_remote_stop_c1 == 0) and (self.my_remote_stop_c2 == 0):
                    await self.send_meter_values(1)
                    await self.send_meter_values(2)
                    time.sleep(4)

            if self.finshing_sent_c1 == '1':
                self.start_sendMeterValue_SW1 == 1

                fw1 = open("start_sendMeterValue_SW1.txt", "w")
                fw1.write(str(self.start_sendMeterValue_SW1))
                fw1.close()

            if self.finshing_sent_c2 == '1':
                self.start_sendMeterValue_SW2 == 1

                fw1 = open("start_sendMeterValue_SW2.txt", "w")
                fw1.write(str(self.start_sendMeterValue_SW2))
                fw1.close()

            self.emergency_sent_c1 = read_Emergency_stop(self.myip_adr_c1)
            if self.emergency_sent_Sw_c1 == 1:
                if self.emergency_sent_c1 == "1":
                    await self.status_notification_emer(1)

                    self.emergency_sent_Sw_c1 = 2
                    f = open("emergency_sent_Sw_c1.txt", "w")
                    f.write(str(self.emergency_sent_Sw_c1))
                    f.close()

                    if self.iCpStateCss1 == 'Charging':
                        try:
                            await self.send_stop_transaction(1, reasonf='EmergencyStop')
                            self.block1 = 3
                            f = open("block1.txt", "w")
                            f.write(str(self.block1))
                            f.close()

                            ## Clear Transaction ID
                            f = open("translogs1.txt", "w")
                            f.write(str(0))
                            f.close()

                        except Exception as e:
                            print(f"## error line 1084 {e}")
                    else:
                        pass
            else:
                if self.emergency_sent_c1 == '0':
                    await self.status_notification_cp(1)
                    self.emergency_sent_Sw_c1 = 1
                    f = open("emergency_sent_Sw_c1.txt", "w")
                    f.write(str(self.emergency_sent_Sw_c1))
                    f.close()

            self.emergency_sent_c2 = read_Emergency_stop(self.myip_adr_c2)
            if self.emergency_sent_Sw_c2 == 1:
                if self.emergency_sent_c2 == "1":
                    await self.status_notification_emer(2)

                    self.emergency_sent_Sw_c2 = 2
                    f = open("emergency_sent_Sw_c2.txt", "w")
                    f.write(str(self.emergency_sent_Sw_c2))
                    f.close()

                    if self.iCpStateCss2 == 'Charging':
                        try:
                            await self.send_stop_transaction(2, reasonf='EmergencyStop')

                            self.block2 = 3
                            f = open("block2.txt", "w")
                            f.write(str(self.block2))
                            f.close()

                            ## Clear Transaction ID
                            f = open("translogs2.txt", "w")
                            f.write(str(0))
                            f.close()

                        except Exception as e:
                            print(f"## error line 1103 {e}")
                    else:
                        pass
            else:
                if self.emergency_sent_c2 == '0':
                    await self.status_notification_cp(2)
                    self.emergency_sent_Sw_c2 = 1
                    f = open("emergency_sent_Sw_c2.txt", "w")
                    f.write(str(self.emergency_sent_Sw_c2))
                    f.close()
            await asyncio.sleep(interval)

DEFAULT_URL = "ws://212.80.215.42:9000/ocpp/TACT30KW"

SN = "TESTSetting" 

start_ocpp_watcher(SN)
time.sleep(2)

# ===== DEBUG: ???? MongoDB connection =====
try:
    from pymongo import MongoClient as _MC
    _c = _MC("mongodb://imps_platform:eds_imps@203.154.130.132:27017/", serverSelectionTimeoutMS=5000)
    _c.admin.command("ping")
    print("? MongoDB connected")
    _doc = _c["iMPS"]["charger"].find_one({"SN": SN})
    if _doc:
        print(f"? Found SN={SN}")
        print(f"   ocppUrl: {_doc.get('ocppUrl', '? MISSING')}")
        print(f"   chargeBoxID: {_doc.get('chargeBoxID', '? MISSING')}")
    else:
        print(f"? SN='{SN}' not found")
        print(f"   All SNs: {_c['iMPS']['charger'].distinct('SN')}")
    _c.close()
except Exception as e:
    print(f"? MongoDB error: {e}")

# ??????? ocpp_config.txt ???????????????
_url = read_ocpp_config()
print(f"?? ocpp_config.txt content: '{_url}'")
# ===== END DEBUG =====

async def main():
    # url = "wss://ev-ocpp.egat.co.th/ocpp/EDS_150_3"
    # url = "ws://212.80.215.42:9000/ocpp/TACT30KW"
    url = read_ocpp_config()
    if not url:
        url = DEFAULT_URL
        print(f"?? No OCPP config, fallback: {url}")
    else:
        print(f"?? OCPP URL from MongoDB: {url}")
 
    async with websockets.connect(url, subprotocols=["ocpp1.6"]) as ws:
        cp_cls = ChargePoint('CP_1', ws, iCpStateCss1=icp_ini1, iCpStateCss2=icp_ini2, )
        notifier.notify("READY=1")
        await asyncio.gather(
            cp_cls.start(),
            cp_cls.loss_network_regis(),
            cp_cls.boot_notification_cp(),
            cp_cls.status_notification_cp(1),
            cp_cls.status_notification_cp(2),
            cp_cls.send_heartbeat(),
            cp_cls.main_run_program(0),
            systemd_watchdog_task(),
        )


while (1):
    try:
        asyncio.run(main())
    except Exception as e:
        f = open("MDBlog.txt", "a")
        f.write(f"{e} | {datetime.now(pytz.timezone('Asia/Bangkok')).strftime('%Y-%m-%dT%H:%M:%S.%f')}\n")
        f.close()
        print(f"## error {e}")
        res_te = line_notify("TACT30kW (Disconnect): Error is "+str(e))
        print(res_te)
        time.sleep(5)