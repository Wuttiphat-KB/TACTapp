#!/usr/bin/env python3
"""
gen_telemetry.py — อ่านค่า DSE4620 (RPM / Voltage / Fuel ฯลฯ) ผ่าน DSE857 (Modbus RTU)
แล้วส่งขึ้น TACT backend เพื่อแสดงใน mobile app

ต่อยอดจาก Gen.py เดิม เพิ่ม:
  1) POST ค่าขึ้น backend  ->  POST /api/telemetry/generator
  2) reconnect อัตโนมัติเมื่อสาย serial หลุด
  3) กันล้ม: การ POST ล้มเหลว "ห้าม" ทำให้ poller ตาย

เป็น process แยกจาก CP.py (sidecar) — ถือ /dev/ttyUSB0 คนเดียว ไม่ยุ่งกับ OCPP
รันคู่กับ CP.py ได้เลย (CP.py ใช้ energy meter ที่ /dev/ttyACM0 คนละเส้น)

ENV (ตั้งก่อนรันได้ ถ้าไม่ตั้งใช้ default):
  TACT_BACKEND_URL   default http://212.80.215.42:5000/api/telemetry/generator
  TACT_DEVICE_KEY    default ""  (ต้องตรงกับ DEVICE_API_KEY ใน backend .env ถ้า backend เปิดใช้)
  TACT_CP_ID         default TACT30KW

deploy บน EdgeBox ด้วย heredoc (กัน non-UTF-8):
  cat > /home/pi/gen_telemetry.py << 'EOF'
  ...(เนื้อไฟล์นี้)...
  EOF
  pip install pymodbus requests
  python3 /home/pi/gen_telemetry.py
"""

import os
import time
import inspect
import requests
from datetime import datetime
from pymodbus.client import ModbusSerialClient

# ---------- Modbus config (ยืนยันแล้วจาก log จริง) ----------
PORT = "/dev/ttyUSB0"
SLAVE = 11          # DSE857 Passthrough Slave ID → DSE4620
BASE = 1024         # page 4 = 4*256 = Basic Instrumentation (จุดที่ค่าจริงอยู่)
COUNT = 20          # อ่าน 1024..1043 ในข้อความเดียว
INTERVAL = 5        # วินาที ต่อรอบ

# ---------- Backend config ----------
BACKEND_URL = os.environ.get("TACT_BACKEND_URL", "http://212.80.215.42:5000/api/telemetry/generator")
DEVICE_KEY = os.environ.get("TACT_DEVICE_KEY", "")
CP_ID = os.environ.get("TACT_CP_ID", "TACT30KW")
POST_TIMEOUT = 3    # วินาที — สั้น ๆ กันค้าง event loop ของ poller

SENTINEL = {0x7FFD, 0x7FFE, 0x7FFF, 0xFFFD, 0xFFFE, 0xFFFF}

# name: (label, unit)
LABELS = {
    "rpm":       ("Engine Speed", "rpm"),
    "freq_hz":   ("Frequency",    "Hz"),
    "fuel_pct":  ("Fuel Level",   "%"),
    "battery_v": ("Battery",      "V"),
    "charge_v":  ("Charge Alt",   "V"),
    "oil_kpa":   ("Oil Pressure", "kPa"),
    "coolant_c": ("Coolant Temp", "degC"),
    "l1n_v":     ("Gen L1-N",     "V"),
    "l2n_v":     ("Gen L2-N",     "V"),
    "l3n_v":     ("Gen L3-N",     "V"),
    "l1l2_v":    ("Gen L1-L2",    "V"),
    "l2l3_v":    ("Gen L2-L3",    "V"),
    "l3l1_v":    ("Gen L3-L1",    "V"),
}

client = ModbusSerialClient(port=PORT, baudrate=19200, parity="N",
                            stopbits=1, bytesize=8, timeout=1)

# pymodbus >=3.9 เปลี่ยน kwarg จาก slave= เป็น device_id=
_PARAMS = inspect.signature(client.read_holding_registers).parameters
_ID_KW = "device_id" if "device_id" in _PARAMS else "slave"


def u16(regs, addr):
    v = regs[addr - BASE]
    return None if v in SENTINEL else v


def u32(regs, addr):
    i = addr - BASE
    if regs[i + 1] in SENTINEL:
        return None
    return (regs[i] << 16) | regs[i + 1]      # MSW first (ยืนยันจาก ground truth 231.1V)


def read():
    rr = client.read_holding_registers(address=BASE, count=COUNT, **{_ID_KW: SLAVE})
    if rr.isError():
        return None
    r = rr.registers

    def scale(v, f):
        return round(v * f, 1) if v is not None else None

    return {
        "rpm":        u16(r, 1030),
        "freq_hz":    scale(u16(r, 1031), 0.1),
        "fuel_pct":   u16(r, 1027),
        "battery_v":  scale(u16(r, 1029), 0.1),
        "charge_v":   scale(u16(r, 1028), 0.1),
        "oil_kpa":    u16(r, 1024),
        "coolant_c":  u16(r, 1025),
        "l1n_v":      scale(u32(r, 1032), 0.1),
        "l2n_v":      scale(u32(r, 1034), 0.1),
        "l3n_v":      scale(u32(r, 1036), 0.1),
        "l1l2_v":     scale(u32(r, 1038), 0.1),
        "l2l3_v":     scale(u32(r, 1040), 0.1),
        "l3l1_v":     scale(u32(r, 1042), 0.1),
    }


def show(data):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"--- {ts} " + "-" * 27)
    if data is None:
        print("  read error")
        return
    for key, (label, unit) in LABELS.items():
        val = data[key]
        val = "n/a" if val is None else f"{val} {unit}"
        print(f"  {label:<14}: {val}")
    print()


def post_backend(data):
    """ส่งค่าขึ้น backend. ล้มเหลวได้ ห้าม raise ออกไปฆ่า poller"""
    if data is None:
        return
    payload = dict(data)
    payload["cpId"] = CP_ID
    headers = {"Content-Type": "application/json"}
    if DEVICE_KEY:
        headers["X-Device-Key"] = DEVICE_KEY
    try:
        requests.post(BACKEND_URL, json=payload, headers=headers, timeout=POST_TIMEOUT)
    except Exception as e:
        print(f"  [backend] post failed: {e}")


def reconnect():
    """ปิด/เปิด serial ใหม่เมื่ออ่านไม่ได้ (สายหลุด / DSE857 รีบูต)"""
    try:
        client.close()
    except Exception:
        pass
    time.sleep(1)
    try:
        return client.connect()
    except Exception as e:
        print(f"  [modbus] reconnect failed: {e}")
        return False


if __name__ == "__main__":
    if not client.connect():
        print("[modbus] initial connect failed — จะลองใหม่ในลูป")

    try:
        while True:
            data = None
            try:
                data = read()
            except Exception as e:
                print(f"  [modbus] read exception: {e}")
                data = None

            if data is None:
                reconnect()   # อ่านไม่ได้ → พยายามต่อใหม่ก่อนรอบหน้า

            show(data)
            post_backend(data)   # ส่งขึ้น backend (None ก็ไม่ส่ง)
            time.sleep(INTERVAL)
    except KeyboardInterrupt:
        pass
    finally:
        client.close()
