#!/usr/bin/env python3
# dse_probe.py -- READ ONLY diagnostic. FC3 (read holding registers) only.
# No writes, no control keys. Safe with generator stopped OR running.
# Purpose: settle "page 0 vs page 4" and "passthrough alive vs USB link down" in ONE run.

import sys
import minimalmodbus
import serial

PORT = "/dev/ttyUSB0"
BAUD = 19200

def mk(slave):
    i = minimalmodbus.Instrument(PORT, slave)
    i.serial.baudrate = BAUD
    i.serial.bytesize = 8
    i.serial.parity   = serial.PARITY_NONE
    i.serial.stopbits = 1
    i.serial.timeout  = 2.0
    i.mode = minimalmodbus.MODE_RTU
    i.clear_buffers_before_each_transaction = True
    return i

def block(inst, base, count, label):
    # ONE FC3 message per block -- GenComm SP-228 6.1 note 6 forbids assembling
    # a 32-bit value from multiple messages (torn half-old data).
    try:
        regs = inst.read_registers(base, count, functioncode=3)
        print("  OK    %-30s base=%-5d count=%-3d" % (label, base, count))
        return regs
    except Exception as e:
        print("  FAIL  %-30s base=%-5d count=%-3d -> %s: %s"
              % (label, base, count, type(e).__name__, e))
        return None

# ---- DSE sentinel filtering (SP-228 6.1). Sentinel -> None, NEVER a number. ----
def u16(r, i):
    if r is None or i >= len(r): return None
    v = r[i]
    return None if v >= 0xFFF8 else v

def s16(r, i):
    if r is None or i >= len(r): return None
    v = r[i]
    if 0x7FF8 <= v <= 0x7FFF: return None
    return v - 65536 if v > 32767 else v

def u32(r, i):
    # high-word-first -- INFERRED from the team's own Config Suite ground truth
    # (231.1 V, 51.3 Hz), NOT cited from SP-228. If page 4 decodes to nonsense,
    # flip to (r[i+1] << 16) | r[i] before concluding the chain is broken.
    if r is None or i + 1 >= len(r): return None
    v = (r[i] << 16) | r[i+1]
    return None if v >= 0xFFFFFFF8 else v

def sc(v, f):
    return None if v is None else round(v * f, 2)

def show(label, val, unit=""):
    print("    %-28s %s %s" % (label, "None (sentinel/unimpl)" if val is None else val, unit))

print("=" * 72)
print("DSE PROBE -- READ ONLY -- port=%s baud=%d" % (PORT, BAUD))
print("=" * 72)

# ---------- [1] PAGE 0 at slave 10 vs 11 : hub-vs-controller discriminator ----------
print("\n[1] PAGE 0 (base 0) -- Communications Status. Slave 10 = DSE857 config,")
print("    slave 11 = passthrough relay to DSE4620.")
for sl in (10, 11):
    print("  -- slave %d --" % sl)
    try:
        inst = mk(sl)
    except Exception as e:
        print("     cannot open port: %s: %s" % (type(e).__name__, e)); sys.exit(1)
    p0 = block(inst, 0, 12, "page0 off0-11")
    if p0:
        show("off0  ext exception code", u16(p0, 0), "(12 = 'Reserved register')")
        show("off6  password status",    u16(p0, 6), "(3 = full access)")
        show("off7  satellite sockets",  u16(p0, 7), "<== 0 = CONTROL UNIT, >=1 = HUB")
        show("off9  GenComm version",    u16(p0, 9))
        show("off10 baud bitmask hi",    u16(p0, 10))
        show("off11 baud bitmask lo",    u16(p0, 11))
    inst.serial.close()

inst = mk(11)

# ---------- [2] PAGE 3 : identity proof of end-to-end passthrough ----------
print("\n[2] PAGE 3 (base 768) -- Generating Set Status / identity, slave 11")
p3 = block(inst, 768, 7, "page3 off0-6")
if p3:
    show("768 manufacturer code", u16(p3, 0))
    show("769 MODEL NUMBER",      u16(p3, 1), "<== a 46xx here PROVES passthrough to the DSE4620")
    show("770 serial number",     u32(p3, 2))
    show("772 control mode",      u16(p3, 4), "(0=Stop 1=Auto 2=Manual 3=Test 7=Off)")
    fl = u16(p3, 6)
    show("774 flags register",    fl)
    if fl is not None:
        print("      bit13 shutdown alarm = %d | bit11 warning alarm = %d"
              % ((fl >> 12) & 1, (fl >> 10) & 1))

# ---------- [3] PAGE 4 : THE TEST. Never attempted before. ----------
print("\n[3] PAGE 4 (base 1024 = 4*256) -- Basic Instrumentation, slave 11")
print("    *** THIS IS THE TEST. The page*256 multiplier was never applied. ***")
p4 = block(inst, 1024, 35, "page4 off0-34")
if p4:
    show("1024 oil pressure",   u16(p4, 0), "kPa")
    show("1025 coolant temp",   s16(p4, 1), "degC")
    show("1027 FUEL LEVEL",     u16(p4, 3), "%   <== the field the App renders")
    show("1029 battery volts",  sc(u16(p4, 5), 0.1), "V")
    show("1030 ENGINE SPEED",   u16(p4, 6), "RPM")
    show("1031 FREQUENCY",      sc(u16(p4, 7), 0.1), "Hz  <== expect ~51.3")
    show("1032 gen L1-N",       sc(u32(p4, 8),  0.1), "V   <== expect ~231.1")
    show("1034 gen L2-N",       sc(u32(p4, 10), 0.1), "V   <== expect ~231.8")
    show("1036 gen L3-N",       sc(u32(p4, 12), 0.1), "V   <== expect ~231.3")
    show("1038 gen L1-L2",      sc(u32(p4, 14), 0.1), "V   <== expect ~401.1")
    show("1044 gen L1 current", sc(u32(p4, 20), 0.1), "A")
    show("1046 gen L2 current", sc(u32(p4, 22), 0.1), "A")
    show("1048 gen L3 current", sc(u32(p4, 24), 0.1), "A")
    show("1052 gen L1 watts",   u32(p4, 28), "W")

# ---------- [4] PAGE 6 / PAGE 7 : may be unimplemented on a small AMF module ----------
print("\n[4] PAGE 6 (base 1536) -- Derived Instrumentation, slave 11")
p6 = block(inst, 1536, 22, "page6 off0-21")
if p6:
    tw = u32(p6, 0)
    show("1536 gen total watts", tw, "W")
    show("     -> total kW",     None if tw is None else round(tw / 1000.0, 2), "kW")
    show("1557 gen average PF",  sc(s16(p6, 21), 0.01))

print("\n[5] PAGE 7 (base 1792) -- Accumulated Instrumentation, slave 11")
p7 = block(inst, 1792, 36, "page7 off0-35")
if p7:
    rt = u32(p7, 6)
    show("1798 engine run time", rt, "s")
    show("     -> hours",        None if rt is None else round(rt / 3600.0, 1), "h")
    show("1800 gen positive",    sc(u32(p7, 8), 0.1), "kWh")
    show("1808 number of starts", u32(p7, 16))
    show("1826 FUEL USED",       u32(p7, 34), "L   <== feeds ChargingSession.fuelUsed")

inst.serial.close()

print("\n" + "=" * 72)
print("DECISION RULE")
print("=" * 72)
print("  page 4 returns live numbers (~51.3 Hz, ~231 V)")
print("      -> passthrough was ALWAYS fine. The bug was page 0 vs page 4. Ship the poller.")
print("  page 4 decodes to absurd values (e.g. 0x0907_0000)")
print("      -> flip 32-bit word order to low-word-first, re-run. Do NOT blame the wiring.")
print("  page 4 -> exception code 10 or 11 (gateway path unavailable / target no response)")
print("      -> DSE857 cannot reach the 4620 over USB. Fix the USB A-B cable (DSE 016-125).")
print("         Software cannot help. Check the LED FLASH RATE (slow = no USB link).")
print("  page 4 -> exception 1 or 2 while page 0 still answers")
print("      -> the responder is not a real GenComm control unit. Check page 0 off7:")
print("         >=1 means the DSE857 hub is answering for itself, not relaying.")
print("  1027 (fuel level) -> None while everything else is live")
print("      -> NO FUEL SENDER is wired to the 4620 analog input. The fuel gauge has no")
print("         real source under ANY transport. Report this to the client and redesign")
print("         the capacity row around freq/voltage/current/status instead.")
print("=" * 72)
