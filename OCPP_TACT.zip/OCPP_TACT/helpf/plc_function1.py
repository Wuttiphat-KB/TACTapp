import os
import re
import time
import json
import requests
import pytz
from datetime import datetime

def convert_timeformat(current_time):
    # bangkok_timezone = pytz.timezone('Asia/Bangkok')
    # current_time = datetime.now(tz=bangkok_timezone)
    formatted_time = current_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + 'Z'
    print(f"## formatted_time: {formatted_time}")  # Output will be in the form '2023-08-08T09:32:28.000Z'
    return formatted_time

###################### GET SOC #########################
def get_soc(ip_adr):
    # url = "http://192.168.0.9/cgi-bin/ILRReadValues.exe"
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload = "<n>@GV.iRessState</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response = requests.request("POST", url, headers=headers, data=payload)
    data = response.text
    # match_n = re.search('<n>(.*?)</n>', data)
    match_v = re.search('<v>(.*?)</v>', data)
    # value_n = match_n.group(1)[4:] if match_n else None
    value_v = match_v.group(1) if match_v else None
    # print(f"Tag Name {value_n} Value {value_v}")
    # tag_info = {'Tag_name':value_n, 'Tag_value':value_v}
    return value_v
########################## Remote Start PLC #########################
def remote_start_plc(ip_adr, value):
    # url = "http://192.168.0.9/cgi-bin/writeVal.exe?%40GV.remote_start_webvisit+1"
    url = "http://"+ip_adr+"/cgi-bin/writeVal.exe?%40GV.remote_start_webvisit+"+str(value)
    payload, headers = {}, {}
    response = requests.request("GET", url, headers=headers, data=payload)
    data = response.text
    print(f"## remote_start_plc: {data}")
    return 'Remote Start Successful'
########################## Remote Stop PLC ##########################
def remote_stop_plc(ip_adr, value):
    # url = "http://192.168.0.9/cgi-bin/writeVal.exe?%40GV.remote_start_webvisit+1"
    url = "http://"+ip_adr+"/cgi-bin/writeVal.exe?%40GV.remote_stop_webvisit+"+str(value)
    payload, headers = {}, {}
    response = requests.request("GET", url, headers=headers, data=payload)
    data = response.text
    print(f"## remote_stop_plc: {data}")
    return 'Remote Stop Successful'
######################### iCpStateCcs & usiLinkStateCcs ##############
# Read tag
def read_tag_status(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload1 = "<n>@GV." + "iCpStateCcs" + "</n>\r\n"
    payload2 = "<n>@GV." + "usiLinkStateCcs" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response1 = requests.request("POST", url, headers=headers, data=payload1)
    response2 = requests.request("POST", url, headers=headers, data=payload2)
    data1, data2 = response1.text, response2.text

    match_n1 = re.search('<n>(.*?)</n>', data1)
    value_n1 = match_n1.group(1)[4:] if match_n1 else None
    match_v1 = re.search('<v>(.*?)</v>', data1)
    value_v1 = match_v1.group(1) if match_v1 else None ## Value

    match_n2 = re.search('<n>(.*?)</n>', data2)
    value_n2 = match_n2.group(1)[4:] if match_n2 else None
    match_v2 = re.search('<v>(.*?)</v>', data2)
    value_v2 = match_v2.group(1) if match_v2 else None ## Value

    if value_n1 == 'iCpStateCcs':
        if value_v1 == '1':
            value_v1 = 'Available'
        elif value_v1 == '6':
            value_v1 = 'Preparing'
        # elif value_v1 in ['3', '4', '5','6', '7','8']:
        #     value_v1 = 'Charging'
        elif (value_v1 == '7') and (value_v2 == '13'):
            value_v1 = 'Charging'
        elif value_v1 in ['9', '10']:
            value_v1 = 'Faulted'
        else:
            value_v1 = 'Unavailable'
            # print("Not match iCpStateCcs")
    # print('value_v1', value_v1)
    # print('value_v2', value_v2)

    if value_n2 == 'usiLinkStateCcs':
        if value_v2 == '0':
            value_v2 = 'Available'
        elif value_v2 in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '21', '22']:
            value_v2 = 'Preparing'
        elif value_v2 in ['12', '13', '19']:
            value_v2 = 'Charging'
        # elif value_v2 in ['14']:
        #     value_v2 = 'Faulted'
        elif value_v2 in ['14', '15', '16', '20']:
            value_v2 = 'Finishing'
        elif value_v2 in ['17', '18']:
            value_v2 = 'SuspendedEV'
        else:
            value_v2 = 'Unavailable'
            # print("Not match usiLinkStateCcs")


    return value_v1, value_v2


############################ Tag raed ################################
def read_tag_value(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload1 = "<n>@GV." + "Tag_raed" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response1 = requests.request("POST", url, headers=headers, data=payload1)
    data1 = response1.text
    # match_n1 = re.search('<n>(.*?)</n>', data1)
    match_v1 = re.search('<v>(.*?)</v>', data1)
    # value_n1 = match_n1.group(1)[4:] if match_n1 else None
    value_v1 = match_v1.group(1) if match_v1 else None  ## Value
    if value_v1 == None:
        value_v1 = ""
    return value_v1

############################ Emergency ###############################
def read_Emergency_stop(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload = "<n>@GV." + "Emergency_stop" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response = requests.request("POST", url, headers=headers, data=payload)
    data = response.text
    # match_n1 = re.search('<n>(.*?)</n>', data)
    match_v1 = re.search('<v>(.*?)</v>', data)
    # value_n1 = match_n1.group(1)[4:] if match_n1 else None
    value_v1 = match_v1.group(1) if match_v1 else None
    return value_v1
#########################################################

def Head1Finishing(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload1 = "<n>@GV." + "Head1Finishing" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response1 = requests.request("POST", url, headers=headers, data=payload1)
    data1 = response1.text
    match_v1 = re.search('<v>(.*?)</v>', data1)
    value_v1 = match_v1.group(1) if match_v1 else None  ## Value
    return value_v1

def Head2Finishing(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload1 = "<n>@GV." + "Head2Finishing" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response1 = requests.request("POST", url, headers=headers, data=payload1)
    data1 = response1.text
    match_v1 = re.search('<v>(.*?)</v>', data1)
    value_v1 = match_v1.group(1) if match_v1 else None  ## Value
    return value_v1

def read_tag_read1(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload1 = "<n>@GV." + "Tag_read1" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response1 = requests.request("POST", url, headers=headers, data=payload1)
    data1 = response1.text
    match_v1 = re.search('<v>(.*?)</v>', data1)
    value_v1 = match_v1.group(1) if match_v1 else None  ## Value
    return value_v1

def read_tag_read2(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload1 = "<n>@GV." + "Tag_read2" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response1 = requests.request("POST", url, headers=headers, data=payload1)
    data1 = response1.text
    match_v1 = re.search('<v>(.*?)</v>', data1)
    value_v1 = match_v1.group(1) if match_v1 else None  ## Value
    return value_v1

def read_OCPP_HardReset1(ip_adr, value):
    # url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    url = "http://" + ip_adr + "/cgi-bin/writeVal.exe?%40GV.OCPP_HardReset1+" + str(value)
    payload, headers = {}, {}
    response = requests.request("GET", url, headers=headers, data=payload)
    data = response.text
    print(f"## read_OCPP_HardReset1: {data}")
    return "Hard reset"

def read_OCPP_HardReset2(ip_adr, value):
    url = "http://" + ip_adr + "/cgi-bin/writeVal.exe?%40GV.OCPP_HardReset2+" + str(value)
    payload, headers = {}, {}
    response = requests.request("GET", url, headers=headers, data=payload)
    data = response.text
    print(f"## read_OCPP_HardReset2: {data}")
    return "Hard reset"

def finish_one_c1(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload1 = "<n>@GV." + "Head1Done" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response1 = requests.request("POST", url, headers=headers, data=payload1)
    data1 = response1.text
    match_v1 = re.search('<v>(.*?)</v>', data1)
    value_v1 = match_v1.group(1) if match_v1 else None  ## Value
    print(f"## Head1Done: {value_v1}")
    return value_v1

def finish_one_c2(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload1 = "<n>@GV." + "Head2Done" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response1 = requests.request("POST", url, headers=headers, data=payload1)
    data1 = response1.text
    match_v1 = re.search('<v>(.*?)</v>', data1)
    value_v1 = match_v1.group(1) if match_v1 else None  ## Value
    print(f"## Head2Done: {value_v1}")
    return value_v1

def tag_status_recn(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload2 = "<n>@GV." + "usiLinkStateCcs" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response2 = requests.request("POST", url, headers=headers, data=payload2)
    data2 = response2.text
    match_n2 = re.search('<n>(.*?)</n>', data2)
    value_n2 = match_n2.group(1)[4:] if match_n2 else None
    match_v2 = re.search('<v>(.*?)</v>', data2)
    value_v2 = match_v2.group(1) if match_v2 else None ## Value
    return value_v2

def cmd_low(ip_adr, value):
    url = "http://" + ip_adr + "/cgi-bin/writeVal.exe?%40GV.lowpiority+" + str(value)
    payload, headers = {}, {}
    response = requests.request("GET", url, headers=headers, data=payload)
    data = response.text
    print(f"## read_OCPP_HardReset2: {data}")
    return "force limit current"

def h1_error(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload2 = "<n>@GV." + "Head2Error" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response2 = requests.request("POST", url, headers=headers, data=payload2)
    data2 = response2.text
    match_n2 = re.search('<n>(.*?)</n>', data2)
    value_n2 = match_n2.group(1)[4:] if match_n2 else None
    match_v2 = re.search('<v>(.*?)</v>', data2)
    value_v2 = match_v2.group(1) if match_v2 else None ## Value
    return value_v2

#### InsuFault  iCpStateCcs  usiLinkStateCcs
def InsuFault_tag(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload1 = "<n>@GV." + "InsuFault" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response1 = requests.request("POST", url, headers=headers, data=payload1)
    data1 = response1.text
    match_v1 = re.search('<v>(.*?)</v>', data1)
    value_v1 = match_v1.group(1) if match_v1 else None  ## Value
    return value_v1

def iCpStateCcs_tag(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload1 = "<n>@GV." + "iCpStateCcs" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response1 = requests.request("POST", url, headers=headers, data=payload1)
    data1 = response1.text
    match_v1 = re.search('<v>(.*?)</v>', data1)
    value_v1 = match_v1.group(1) if match_v1 else None  ## Value
    return value_v1

def usiLinkStateCcs_tag(ip_adr):
    url = "http://"+ip_adr+"/cgi-bin/ILRReadValues.exe"
    payload1 = "<n>@GV." + "usiLinkStateCcs" + "</n>\r\n"
    headers = {'Content-Type': 'text/plain'}
    response1 = requests.request("POST", url, headers=headers, data=payload1)
    data1 = response1.text
    match_v1 = re.search('<v>(.*?)</v>', data1)
    value_v1 = match_v1.group(1) if match_v1 else None  ## Value
    return value_v1

def line_notify(message):
    url = 'https://notify-api.line.me/api/notify'
    token = 'trzbyFgEtKXKI9BgsjcqAZD8yUdjEJ30mK55xRxh5nL'  #
    headers = {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Authorization': 'Bearer ' + token
                }
    data = {'message': message}
    r = requests.post(url, headers=headers, data=data)
    print(r.text)

def limitpower(ip_adr, limit_power):
    url = "http://" + ip_adr + "/cgi-bin/writeVal.exe?%40GV.limitpower+" + str(limit_power)
    payload, headers = {}, {}
    response = requests.request("GET", url, headers=headers, data=payload)
    data = response.text
    # iCpStateCss1, usiLinkStateCcs1 = read_tag_status(ip_adr)
    # live_data = get_livemeasure(self.my_meter_ip_c2)
    # voltage, current = live_data['voltage'], live_data['current']
    #
    # if iCpStateCss1 == 'Charging' and usiLinkStateCcs1 == 'Charging':
    #     limit_current = limit_power/
    print(f"limitpower ok: {data}")
    return "limitpower ok."

def limitcurrent(ip_adr, value):
    url = "http://" + ip_adr + "/cgi-bin/writeVal.exe?%40GV.limitcurrent+" + str(value)
    payload, headers = {}, {}
    response = requests.request("GET", url, headers=headers, data=payload)
    data = response.text
    print(f"limitcurrent ok: {data}")
    return "limitcurrent ok."

def limit2connector(ip_adr, value):
    url = "http://" + ip_adr + "/cgi-bin/writeVal.exe?%40GV.connector0+" + str(value)
    payload, headers = {}, {}
    response = requests.request("GET", url, headers=headers, data=payload)
    data = response.text
    print(f"limit2connector ok: {data}")
    return "limit2connector ok."

#line_notify("InsuFault_data Test")

# ########################## InsuFault ##########################
# ip_ctrl1 = '192.168.0.8'
# InsuFault_data = InsuFault_tag(ip_ctrl1)
# print(f"InsuFault_data 1: {InsuFault_data}")
# ip_ctrl2 = '192.168.0.9'
# InsuFault_data = InsuFault_tag(ip_ctrl2)
# print(f"InsuFault_data 2: {InsuFault_data}")
# print("##############################################")
#
#
# ########################## iCpStateCcs_tag ##########################
# ip_ctrl1 = '192.168.0.8'
# iCpStateCcs_data = iCpStateCcs_tag(ip_ctrl1)
# print(f"iCpStateCcs 1: {InsuFault_data}")
# ip_ctrl2 = '192.168.0.9'
# iCpStateCcs_data = iCpStateCcs_tag(ip_ctrl2)
# print(f"iCpStateCcs 2: {InsuFault_data}")
# print("##############################################")
# ########################## usiLinkStateCcs ##########################
# ip_ctrl1 = '192.168.0.8'
# usiLinkStateCcs_data = usiLinkStateCcs_tag(ip_ctrl1)
# print(f"iCpStateCcs 1: {InsuFault_data}")
# ip_ctrl2 = '192.168.0.9'
# usiLinkStateCcs_data = usiLinkStateCcs_tag(ip_ctrl2)
# print(f"iCpStateCcs 2: {InsuFault_data}")
# ######################################################################



# # ip_ctrl1 = '192.168.0.8'
# ip_ctrl2 = '192.168.0.9'
# res = h1_error(ip_ctrl2)
# print(res)

###################### GET SOC #########################
# ip_ctrl1 = '192.168.0.8'
# # ip_ctrl2 = '192.168.0.9'
# res = get_soc(ip_ctrl1)
# print(res)
########################## Remote Start PLC #########################
# ip_adr = '192.168.0.8'
# # ip_adr = '192.168.0.9'
# x = remote_start_plc(ip_adr, 1)
# time.sleep(2)
# x = remote_start_plc(ip_adr, 0)
########################## Remote Stop PLC #########################
# # ip_adr = '192.168.0.8'
# ip_adr = '192.168.0.9'
# x = remote_stop_plc(ip_adr, 1)
# time.sleep(3)
# x = remote_stop_plc(ip_adr, 0)
######################### iCpStateCcs & usiLinkStateCcs ##############
# ip_adr = '192.168.0.8'
# # ip_adr = '192.168.0.9'
# res = read_tag_status(ip_adr)
# print(res)
# print('iCpStateCcs: ', res[0])
# print('usiLinkStateCcs: ', res[1])
############################ Tag raed ################################
# ip_adr = '192.168.0.8'
# # ip_adr = '192.168.0.9'
# res = read_tag_value(ip_adr)
# print(res, len(res))
# # ############################ Emergency ###############################
# ip_adr = '192.168.0.8'
# ip_adr = '192.168.0.9'
# res = read_Emergency_stop(ip_adr)
# print(type(res))
# print(res)
######################## Head 1 Finishing ##############################################
# ip_adr = '192.168.0.8'
# res = Head1Finishing(ip_adr)
# print(type(res), res)
######################## Head 2 Finishing ##############################################
# ip_adr = '192.168.0.9'
# res = Head2Finishing(ip_adr)
# print(type(res), res)
##################### Tag read 1 ##################################################
# ip_adr = '192.168.0.8'
# res = read_tag_read1(ip_adr)
# print(res)
# ##################### Tag read 2 ##################################################
# ip_adr = '192.168.0.9'
# res = read_tag_read2(ip_adr)
# print(res)
# ##################### Tag hard reset 1 ##################################################
# ip_adr = '192.168.0.8'
# res = read_OCPP_HardReset1(ip_adr, 1)
# print(res)
# # ##################### Tag hard reset 2 ##################################################
# ip_adr = '192.168.0.9'
# res = read_OCPP_HardReset2(ip_adr,1)
# print(res)
###########################################################################################
# ip_adr = '192.168.0.8'
# a = finish_one_c1(ip_adr)
# print(type(a))
# print(a)


# os.system("poweroff")
# os.system("sudo reboot")
# os.system('shutdown -r now')
