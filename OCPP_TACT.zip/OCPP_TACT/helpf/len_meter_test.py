import json
import requests
import time
import pytz
import minimalmodbus
from datetime import datetime

def convert_timeformat(current_time):
    formatted_time = current_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + 'Z'
    # print(formatted_time)  # Output will be in the form '2023-08-08T09:32:28.000Z'
    return formatted_time

def get_meter_value_pilot(ip_adr):
    if ip_adr == '/dev/ttyACM0':
        slaveaddr = 1
    else:
        slaveaddr = 2
    print(slaveaddr, ip_adr)
    pilot_meter = minimalmodbus.Instrument('/dev/ttyACM0', slaveaddress=slaveaddr)
    pilot_meter.serial.baudrate = 9600
    pilot_meter.serial.parity = minimalmodbus.serial.PARITY_NONE
    pilot_meter.serial.bytesize = 8
    pilot_meter.serial.stopbits = 1
    pilot_meter.serial.timeout = 1
    pilot_meter.mode = minimalmodbus.MODE_RTU
    
    # energyImportTotalStart = pilot_meter.read_register(registeraddress=5, functioncode=3) * 0.01
  
    Energyhighbit_40005 = pilot_meter.read_register(registeraddress=4, functioncode=3)*0.01
    Energylowbit_40006 = pilot_meter.read_register(registeraddress=5, functioncode=3)*0.01
    KWH_data = Energylowbit_40006 + (Energyhighbit_40005)*(2**16)  
    
    res = {'energyTotal':KWH_data}
    # Close the connection
    pilot_meter.serial.close()
    return res

def get_livemeasure_pilot(ip_adr):
    if ip_adr == '/dev/ttyACM0':
        slaveaddr = 1
    else:
        slaveaddr = 2
    pilot_meter = minimalmodbus.Instrument('/dev/ttyACM0', slaveaddress=slaveaddr)
    pilot_meter.serial.baudrate = 9600
    pilot_meter.serial.parity = minimalmodbus.serial.PARITY_NONE
    pilot_meter.serial.bytesize = 8
    pilot_meter.serial.stopbits = 1
    pilot_meter.serial.timeout = 1
    pilot_meter.mode = minimalmodbus.MODE_RTU
    
    voltage = pilot_meter.read_register(registeraddress=0, functioncode=3) * 0.1
    current = pilot_meter.read_register(registeraddress=1, functioncode=3) * 0.01
    power = voltage * current * 0.001
    
    # energyTotal = pilot_meter.read_register(registeraddress=5, functioncode=3) * 0.01
    Energyhighbit_40005 = pilot_meter.read_register(registeraddress=4, functioncode=3)*0.01
    Energylowbit_40006 = pilot_meter.read_register(registeraddress=5, functioncode=3)*0.01
    KWH_data = Energylowbit_40006 + (Energyhighbit_40005)*(2**16)  
    
    timestamp = convert_timeformat(datetime.now())
    res = {'voltage':voltage, 'current':current, 'power':power, 'timestamp':timestamp, 'energyTotal':KWH_data}
    # Close the connection
    pilot_meter.serial.close()
    return res


res = get_meter_value_pilot('/dev/ttyACM0')
print(res)